# CIS 41B - Exercise Streaming resubmission

## Main files

- `Exercise_Streaming.ipynb`: full class definitions, specific notebook references, keep/replace explanations, small checks, decoded output, and the GUI launch cell.
- `streaming.py`: standalone version of the same four classes.
- `Morse.bin` and `MorseCode.csv`: the supplied input files, unchanged.

Keep these four files together. The notebook is part of this resubmission's documentation, not just an optional way to launch the script. The `checks` folder contains supporting tests and evidence rather than application dependencies.

## Run the script

From the submission folder:

```bash
python3 streaming.py
```

The program loads the CSV, reads the binary file, constructs the bit iterator,
consumes the decoder generator, and opens the decoded message in ScrolledText.
Close the window to exit. The script resolves data paths relative to its own
location, so launching the script by an absolute path also works.

Use a local Python installation with Tkinter and a desktop display. The
application imports only Python standard-library modules; it does not use
pandas, Pillow, a bitstream package, or a database.

## Run the notebook

Open `Exercise_Streaming.ipynb` locally with the notebook and input files in the
working folder. Restart the kernel and run the cells from top to bottom.
The final cell opens Tkinter; it finishes when that window is closed.
All classes are defined in the notebook. It does not import `streaming.py`.

The notebook uses `Path.cwd()` because a normal notebook session does not define
`__file__`. If the kernel starts in a different folder, set `data_folder` in the
setup/check cell to the folder containing the two input files.

## What changed from the previous submission

The two-bit decoding rule and the valid decoded result are retained. The
standalone loader becomes a private helper on `MorseCodeDecoder`; `decode` is a
generator method on that class. It still accepts a `BitIterator` and yields
individual characters. `StreamingApp` owns the paths and decoding dependency,
so the main guard is only a one-line launch, not a procedural workflow.

`BitIterator` connects explicitly to `Parsing.ipynb` section 4b and
`Bits&Bytes.ipynb`'s `BitPlayground.update_display`. The CSV loader connects to
`Parsing.ipynb` section 1a, and the generator to sections 5a/5b/5d. The class
organization and copying accessor are traced to `ClassDesign.ipynb` and
`ExampleAssignment.ipynb` Step 8. The GUI is traced to `Tkinter.ipynb`'s Text Box
tab. Method comments explain the adaptations; the notebook expands them.

The assignment-specific state machine and validation are identified as additions,
not claimed to be ready-made notebook code. In particular, malformed input now
raises an error rather than silently substituting a question mark or guessing a
missing letter terminator. The actual supplied CSV has no header; its first
record is preserved. The optional header shown in the assignment is also accepted.

## Verification

```bash
python3 -m unittest discover -s checks -v
```

GUI tests require a local display. The recorded run used Linux with Xvfb,
Python 3.13.5 and Tk 8.6: 37 tests passed, with none skipped. In addition, all
nine notebook code cells ran in a fresh Jupyter kernel. The test harness
scheduled the real Tkinter window to close so the final cell could finish;
that timer is not in the submitted application or notebook cells.

The tests cover every possible byte, all 40 supplied mappings, 100 repeatable
random round trips, literal bit examples, padding, generator state, invalid
input, exact agreement with the previous valid result, and actual GUI behavior.
The result is 543 characters from 425 input bytes. A separate test-only encoder
reproduces the original file exactly. The application never reads the saved
`checks/decoded_output.txt` result.

The supplied binary file ends on a byte boundary without extra padding chunks.
Padding behavior was checked separately with small examples requiring 0, 2, 4,
and 6 padding bits. The CSV and binary files were also compared byte-for-byte
with the original uploads.

`checks/TEST_RESULTS.txt` contains the recorded results; `checks/gui_preview.png`
is a capture of the running Tkinter window. macOS and Windows were not tested in
this environment.
