# CIS 41B - Exercise Streaming (resubmission)
# Full adaptation notes and small checks: Exercise_Streaming.ipynb

# Tkinter.ipynb imports widgets for many demonstrations. This program only
# keeps the text window, so Pillow, ttk, threading and time are not needed.
# csv is for the supplied lookup file; Path keeps input paths together.
import csv
from pathlib import Path
import tkinter as tk
from tkinter import scrolledtext


class BitIterator:
    """Walk through a bytes object, one MSB-first bit at a time."""

    def __init__(self, data):
        # Adapted from Parsing.ipynb, 4b: StudentIterator.__init__.
        # Keep per-instance state, but replace its file/reader/filter with
        # bytes and a bit position. File reading now belongs to StreamingApp.
        # Private state follows ClassDesign.ipynb, Example 3.
        if not isinstance(data, bytes):
            raise TypeError("BitIterator needs a bytes object.")
        self.__data = data
        self.__position = 0

    def get_position(self):
        return self.__position

    def get_total_bits(self):
        return len(self.__data) * 8

    def __iter__(self):
        # Parsing.ipynb, 4b returns self but also opens its CSV here.
        # These bytes are already loaded, so there is no file to open.
        # Do not reset the position: a for loop must resume this iterator.
        return self

    def __next__(self):
        if self.__position >= self.get_total_bits():
            # Same exhaustion signal as StudentIterator.__next__ (4b).
            raise StopIteration

        # Adapted from Bits&Bytes.ipynb, BitPlayground.update_display():
        # bit_index = BITS - 1 - i; bit_val = (self.state >> bit_index) & 1.
        # Replace the single display value with the current byte. Division
        # locates the byte; the remainder locates its bit, from 7 down to 0.
        # Shift + mask keeps leading zeros without bin() or binary formatting.
        byte = self.__data[self.__position // 8]
        shift = 7 - self.__position % 8
        bit = (byte >> shift) & 1
        self.__position += 1
        return str(bit)

    def __repr__(self):
        # Adapted from ClassDesign.ipynb, Complete: CaesarCipher.__repr__.
        # Report iterator progress instead of cipher configuration.
        return (f"BitIterator(position={self.__position}, "
                f"total_bits={self.get_total_bits()})")


class MorseCodeDecoder:
    """Load a Morse lookup table and yield decoded characters from bits."""

    def __init__(self, csv_filename):
        # Adapted from ExampleAssignment.ipynb, Step 8: MorseCodeEncoder.
        # Keep private state, a copying accessor, a lookup helper and public
        # behavior. Replace its character-to-Morse mapping with Morse-to-text.
        # The mapping comes from the required CSV, not a hard-coded dictionary.
        self.__csv_filename = Path(csv_filename)
        self.__mapping = self.__load_table()

    def get_filename(self):
        return self.__csv_filename

    def get_mapping(self):
        # Step 8's mapping accessor returns a copy. Keep that protection so
        # callers cannot accidentally change later decoding by editing it.
        return dict(self.__mapping)

    def __load_table(self):
        # Adapted from Parsing.ipynb, 1a: csv.reader - lowest-level approach.
        # Keep with-open, newline="" and row iteration. Replace printed student
        # fields with a lookup dictionary. The supplied CSV has no header, so
        # blindly calling next(reader), as 1a does, would discard the A entry.
        # Accept the optional header shown in the assignment, but do not
        # discard a data row. utf-8-sig also handles a possible leading BOM.
        mapping = {}
        first_record = True
        with open(self.__csv_filename, newline="", encoding="utf-8-sig") as file:
            for line_number, row in enumerate(csv.reader(file), start=1):
                if not row or all(not field.strip() for field in row):
                    continue
                if len(row) != 2:
                    raise ValueError(f"CSV line {line_number}: expected two fields.")
                hex_value, morse = [field.strip() for field in row]
                if first_record and (hex_value.upper(), morse.upper()) == (
                        "HEX_VALUE", "MORSE_CODE"):
                    first_record = False
                    continue
                first_record = False

                # Added for this exercise: convert hex character codes and
                # validate the mapping rather than silently skipping bad rows.
                # Example: int("0x41", 16) is 65 and chr(65) is "A".
                try:
                    number = int(hex_value, 16)
                except ValueError as error:
                    raise ValueError(
                        f"CSV line {line_number}: invalid hex value."
                    ) from error
                if not 0 <= number <= 127:
                    raise ValueError(f"CSV line {line_number}: expected an ASCII code.")
                if not morse or any(symbol not in ".-" for symbol in morse):
                    raise ValueError(f"CSV line {line_number}: invalid Morse sequence.")
                if morse in mapping:
                    raise ValueError(f"CSV line {line_number}: duplicate Morse sequence.")
                mapping[morse] = chr(number)

        if not mapping:
            raise ValueError("The Morse CSV contains no character mappings.")
        return mapping

    def __decode_letter(self, morse):
        # Adapted from Step 8's MorseCodeEncoder.__encode_char: keep a checked
        # dictionary lookup, but look up a Morse sequence instead of a letter.
        # A missing sequence is an error, not a made-up '?' in the output.
        if morse not in self.__mapping:
            raise ValueError(f"Unknown Morse sequence: {morse!r}")
        return self.__mapping[morse]

    def decode(self, bits):
        """Yield one character at 00 and one space at 11."""
        # Adapted from Parsing.ipynb, 5a: student_reader(), and 5b's transform.
        # Keep the for-loop/yield pattern. Replace one CSV row per yield with
        # one decoded character. pair and morse are local state saved whenever
        # yield pauses. As a method, decode uses this object's private mapping
        # rather than depending on a variable from a previously run cell.
        if not isinstance(bits, BitIterator):
            raise TypeError("decode needs a BitIterator.")
        pair = ""
        morse = ""

        for bit in bits:
            pair += bit
            if len(pair) < 2:
                continue

            # Added for this exercise, from the assignment's Encoding Rules.
            # This state machine is not code copied from the CSV examples.
            if pair == "10":
                morse += "."
            elif pair == "01":
                morse += "-"
            elif pair == "00":
                # Empty 00 chunks can be final-byte padding. Ignoring them
                # avoids looking up an empty sequence or inventing characters.
                if morse:
                    yield self.__decode_letter(morse)
                    morse = ""
            elif pair == "11":
                # Every letter must end with 00, even before a word boundary.
                # Unlike the previous submission, do not guess a missing 00.
                if morse:
                    raise ValueError("A letter is missing 00 before the word boundary.")
                yield " "
            pair = ""

        # Added validation: do not turn a truncated file into plausible text.
        # A fresh BitIterator has a whole number of bytes, but a partially
        # consumed iterator can also expose an incomplete pair here.
        if pair:
            raise ValueError("Incomplete 2-bit symbol at the end of the stream.")
        if morse:
            raise ValueError("The final letter is missing its 00 terminator.")

    def __repr__(self):
        # Adapted from Step 8's __repr__: summarize the actual decoder state.
        return (f"MorseCodeDecoder(file={self.__csv_filename.name!r}, "
                f"symbols={len(self.__mapping)})")


class MorseGUI:
    """Display decoded text in the previous assignment's text window."""

    def __init__(self, text):
        # Adapted from Tkinter.ipynb, TkinterShowcase.__init__, and the
        # previous streaming.py's MorseGUI. Keep one ScrolledText window.
        # The showcase received an external master; this class owns its root
        # so window creation is not dependent on another notebook cell.
        # Remove the showcase's tabs, image loading and unrelated controls.
        if not isinstance(text, str):
            raise TypeError("MorseGUI needs decoded text.")
        self.__text = text
        self.__root = tk.Tk()
        self.__root.title("Morse Code Decoder")
        self.__root.geometry("800x500")
        self.__build_textbox(text)

    def __build_textbox(self, text):
        # Adapted from Tkinter.ipynb, Text Box tab: build_textbox_tab().
        # Keep ScrolledText, word wrapping, pack(expand=True, fill="both")
        # and insert(). Replace its fixed long_text with constructor data.
        # File reading and Morse decoding stay outside the GUI class.
        self.__text_box = scrolledtext.ScrolledText(
            self.__root, wrap="word", font=("Arial", 13)
        )
        self.__text_box.pack(expand=True, fill="both", padx=10, pady=10)
        self.__text_box.insert(tk.END, text)
        # Keep the previous submission's read-only result so typing cannot
        # change the decoded message. Scrolling and selecting text still work.
        self.__text_box.configure(state="disabled")

    def get_text(self):
        # Return displayed content, not the widget. Tk adds its own final
        # newline; end-1c excludes that newline but preserves encoded spaces.
        return self.__text_box.get("1.0", "end-1c")

    def run(self):
        # Moved from the showcase's main cell into the GUI's public interface.
        self.__root.mainloop()

    def close(self):
        self.__root.destroy()

    def __repr__(self):
        return f"MorseGUI(characters={len(self.__text)})"


class StreamingApp:
    """Coordinate loading, decoding and display without mixing their jobs."""

    def __init__(self, folder):
        # Adapted from ClassDesign.ipynb, Example 4: CaesarCipher owns a Rotor
        # and delegates work to it. Here the app owns a MorseCodeDecoder.
        # The two input paths replace separate notebook/global variables.
        self.__folder = Path(folder)
        self.__binary_file = self.__folder / "Morse.bin"
        self.__decoder = MorseCodeDecoder(self.__folder / "MorseCode.csv")

    def get_folder(self):
        return self.__folder

    def read_text(self):
        # Adapted from BinaryPipes.ipynb, StreamDemo.stream_binary():
        # keep with-open in rb mode and read(). Do not use stream_text(),
        # because these bytes contain packed symbols, not encoded English.
        with open(self.__binary_file, "rb") as file:
            data = file.read()

        # Adapted from Parsing.ipynb, 5d's staged pipeline. Instead of CSV ->
        # filtering -> enrichment, this is bytes -> bits -> characters.
        # BinaryPipes.stream_bitstream formats the entire file as binary text;
        # replace that step with BitIterator as this assignment requires.
        # Reading bytes and joining the final result are still eager; only
        # bit access and character decoding are lazy.
        bits = BitIterator(data)
        return "".join(self.__decoder.decode(bits))

    def run(self):
        # Added driver for the required workflow. The GUI gets finished text,
        # not the decoder's private state, and performs no file parsing.
        text = self.read_text()
        window = MorseGUI(text)
        window.run()

    def __repr__(self):
        return f"StreamingApp(folder={str(self.__folder)!r})"


# Standalone entry point: importing this file defines classes without opening
# files or windows. __file__ locates the inputs next to the script even when
# it is started from another folder; the notebook uses its working folder.
if __name__ == "__main__":
    StreamingApp(Path(__file__).resolve().parent).run()
