"""Additional verification, separate from the submitted application.

Run from the submission folder: python3 -m unittest discover -s checks -v
GUI checks need a desktop display. In Linux automation use xvfb-run.
"""
import ast
import csv
import inspect
import json
import os
from pathlib import Path
import random
import runpy
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FOLDER))
from streaming import BitIterator, MorseCodeDecoder, MorseGUI, StreamingApp


def pack_symbols(symbols):
    """Test-only encoder: pack 2-bit integer symbols four per byte."""
    result = bytearray()
    byte = 0
    count = 0
    for symbol in symbols:
        byte = (byte << 2) | symbol
        count += 1
        if count == 4:
            result.append(byte)
            byte = count = 0
    if count:
        result.append(byte << (2 * (4 - count)))
    return bytes(result)


def encode_for_test(text, mapping):
    """Independent inverse check; the application does not call this."""
    reverse = {character: morse for morse, character in mapping.items()}
    symbols = []
    for character in text:
        if character == " ":
            symbols.append(3)
        else:
            for symbol in reverse[character]:
                symbols.append(2 if symbol == "." else 1)
            symbols.append(0)
    return pack_symbols(symbols)


class BitIteratorTests(unittest.TestCase):
    def test_every_possible_byte_msb_first(self):
        # Arithmetic, rather than the implementation's shift/mask expression.
        for value in range(256):
            expected = [str(value // (2 ** power) % 2) for power in range(7, -1, -1)]
            with self.subTest(value=value):
                self.assertEqual(list(BitIterator(bytes([value]))), expected)

    def test_byte_transition_and_leading_zeros(self):
        self.assertEqual("".join(BitIterator(bytes([0xA0, 0x01]))),
                         "1010000000000001")

    def test_iter_does_not_restart(self):
        bits = BitIterator(bytes([0x80]))
        self.assertIs(iter(bits), bits)
        self.assertEqual(next(bits), "1")
        self.assertEqual(list(bits), ["0"] * 7)
        self.assertEqual(bits.get_position(), 8)

    def test_exhaustion_is_stable(self):
        for data in (b"", b"\x00"):
            bits = BitIterator(data)
            list(bits)
            for repeat in range(2):
                with self.assertRaises(StopIteration):
                    next(bits)
            self.assertEqual(bits.get_position(), len(data) * 8)

    def test_rejects_text_and_other_non_bytes(self):
        for data in ("1010", [10], bytearray([10]), None):
            with self.subTest(data=data), self.assertRaises(TypeError):
                BitIterator(data)

    def test_summary_and_total(self):
        bits = BitIterator(b"\x00\x00")
        self.assertEqual(bits.get_total_bits(), 16)
        self.assertEqual(repr(bits), "BitIterator(position=0, total_bits=16)")


class MappingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.csv_file = Path(self.temp.name) / "table.csv"

    def load(self, text):
        self.csv_file.write_text(text, encoding="utf-8")
        return MorseCodeDecoder(self.csv_file)

    def test_actual_headerless_file_retains_first_row(self):
        decoder = MorseCodeDecoder(FOLDER / "MorseCode.csv")
        mapping = decoder.get_mapping()
        self.assertEqual(len(mapping), 40)
        self.assertEqual(mapping[".-"], "A")
        self.assertEqual(mapping["--."], "G")
        self.assertEqual(mapping["-.-.--"], "!")
        # Check every supplied record, not just the three examples above.
        with open(FOLDER / "MorseCode.csv", newline="") as file:
            for code, morse in csv.reader(file):
                self.assertEqual(mapping[morse.strip()], chr(int(code, 16)))

    def test_optional_header_bom_whitespace_and_blank_rows(self):
        decoder = self.load("\ufeff\n HEX_VALUE , MORSE_CODE \n0x41, .- \n\n0x42,-...\n")
        self.assertEqual(decoder.get_mapping(), {".-": "A", "-...": "B"})

    def test_accessor_does_not_expose_mapping(self):
        decoder = self.load("0x41,.-\n")
        returned = decoder.get_mapping()
        returned[".-"] = "X"
        self.assertEqual(decoder.get_mapping()[".-"], "A")
        self.assertEqual(decoder.get_filename(), self.csv_file)

    def test_bad_csv_records_are_not_silently_skipped(self):
        invalid = ("0x41\n", "0x41,.-,extra\n", "xyz,.-\n",
                   "0x80,.-\n", "-1,.-\n", "0x41,\n", "0x41,.x\n",
                   "0x41,.-\n0x42,.-\n")
        for content in invalid:
            with self.subTest(content=content), self.assertRaises(ValueError):
                self.load(content)

    def test_empty_table_is_an_error(self):
        for content in ("", "\n\n", "HEX_VALUE,MORSE_CODE\n"):
            with self.subTest(content=content), self.assertRaises(ValueError):
                self.load(content)

    def test_missing_file_is_an_error(self):
        with self.assertRaises(FileNotFoundError):
            MorseCodeDecoder(self.csv_file)


class GeneratorTests(unittest.TestCase):
    def setUp(self):
        self.decoder = MorseCodeDecoder(FOLDER / "MorseCode.csv")

    def decode(self, data):
        return "".join(self.decoder.decode(BitIterator(data)))

    def test_is_a_real_lazy_generator(self):
        bits = BitIterator(bytes([0x66, 0x00]))
        gen = self.decoder.decode(bits)
        self.assertTrue(inspect.isgenerator(gen))
        self.assertTrue(inspect.isgeneratorfunction(MorseCodeDecoder.decode))
        self.assertEqual(bits.get_position(), 0)
        self.assertEqual(next(gen), "C")
        self.assertEqual(bits.get_position(), 10)
        self.assertEqual(list(gen), [])

    def test_literal_assignment_c_crosses_byte_boundary(self):
        # 01 10 01 10 00 + six padding zeros -> C.
        self.assertEqual(self.decode(bytes([0x66, 0x00])), "C")

    def test_every_supplied_character(self):
        mapping = self.decoder.get_mapping()
        for character in mapping.values():
            with self.subTest(character=character):
                self.assertEqual(self.decode(encode_for_test(character, mapping)), character)

    def test_empty_input_and_zero_padding(self):
        for data in (b"", b"\x00", b"\x00\x00"):
            self.assertEqual(self.decode(data), "")

    def test_all_possible_valid_padding_lengths(self):
        # H = 10 data bits (6 padding); I = 6 (2); S = 8 (0); E = 4 (4).
        mapping = self.decoder.get_mapping()
        for character in "HISE":
            self.assertEqual(self.decode(encode_for_test(character, mapping)), character)

    def test_one_space_for_each_word_marker(self):
        self.assertEqual(self.decode(bytes([0xFC])), "   ")  # 11 11 11 00
        text = " A  B "
        self.assertEqual(self.decode(encode_for_test(text, self.decoder.get_mapping())), text)

    def test_sos_has_no_extra_space(self):
        self.assertEqual(self.decode(encode_for_test("SOS", self.decoder.get_mapping())), "SOS")

    def test_unknown_sequence_raises_instead_of_question_mark(self):
        with self.assertRaisesRegex(ValueError, "Unknown Morse"):
            self.decode(pack_symbols([2] * 8 + [0]))

    def test_rejects_missing_letter_end_before_word(self):
        with self.assertRaisesRegex(ValueError, "missing 00"):
            self.decode(bytes([0xB0]))  # 10 11 00 00

    def test_rejects_unfinished_final_letter(self):
        with self.assertRaisesRegex(ValueError, "final letter"):
            self.decode(bytes([0xAA]))  # 10 10 10 10, no 00

    def test_rejects_incomplete_pair_from_consumed_iterator(self):
        bits = BitIterator(b"\x00")
        next(bits)
        with self.assertRaisesRegex(ValueError, "Incomplete 2-bit"):
            list(self.decoder.decode(bits))

    def test_requires_bit_iterator(self):
        with self.assertRaises(TypeError):
            list(self.decoder.decode(iter("1000")))

    def test_two_generators_have_independent_local_state(self):
        mapping = self.decoder.get_mapping()
        left = self.decoder.decode(BitIterator(encode_for_test("AB", mapping)))
        right = self.decoder.decode(BitIterator(encode_for_test("CD", mapping)))
        self.assertEqual(next(left), "A")
        self.assertEqual(next(right), "C")
        self.assertEqual(next(left), "B")
        self.assertEqual(next(right), "D")
        self.assertEqual(list(left), [])
        self.assertEqual(list(right), [])

    def test_random_round_trips(self):
        rng = random.Random(41)
        mapping = self.decoder.get_mapping()
        alphabet = list(mapping.values()) + [" "]
        for index in range(100):
            text = "".join(rng.choice(alphabet) for unused in range(rng.randrange(1, 100)))
            with self.subTest(example=index):
                self.assertEqual(self.decode(encode_for_test(text, mapping)), text)


class IntegrationTests(unittest.TestCase):
    def test_actual_text_matches_previous_valid_output(self):
        expected = (FOLDER / "checks" / "decoded_output.txt").read_text()
        actual = StreamingApp(FOLDER).read_text()
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 543)
        self.assertEqual(len((FOLDER / "Morse.bin").read_bytes()), 425)

    def test_actual_file_exact_inverse_round_trip(self):
        mapping = MorseCodeDecoder(FOLDER / "MorseCode.csv").get_mapping()
        result = StreamingApp(FOLDER).read_text()
        self.assertEqual(encode_for_test(result, mapping), (FOLDER / "Morse.bin").read_bytes())

    def test_app_repeats_without_exhausted_iterator(self):
        app = StreamingApp(FOLDER)
        self.assertEqual(app.read_text(), app.read_text())
        self.assertEqual(app.get_folder(), FOLDER)

    def test_import_has_no_window_or_input_read(self):
        with patch("tkinter.Tk", side_effect=AssertionError("unexpected window")), \
             patch("builtins.open", side_effect=AssertionError("unexpected input read")):
            namespace = runpy.run_path(str(FOLDER / "streaming.py"), run_name="import_check")
        self.assertIn("StreamingApp", namespace)

    def test_notebook_contains_identical_complete_classes(self):
        notebook = json.loads((FOLDER / "Exercise_Streaming.ipynb").read_text())
        notebook_classes = {}
        for cell in notebook["cells"]:
            if cell["cell_type"] == "code":
                for node in ast.parse("".join(cell["source"])).body:
                    if isinstance(node, ast.ClassDef):
                        notebook_classes[node.name] = ast.dump(node)
        source = ast.parse((FOLDER / "streaming.py").read_text())
        script_classes = {n.name: ast.dump(n) for n in source.body if isinstance(n, ast.ClassDef)}
        self.assertEqual(set(script_classes), {"BitIterator", "MorseCodeDecoder", "MorseGUI", "StreamingApp"})
        self.assertEqual(notebook_classes, script_classes)

    def test_no_core_binary_formatting(self):
        source = ast.parse((FOLDER / "streaming.py").read_text())
        for node in ast.walk(source):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                self.assertNotIn(node.func.id, ("bin", "format"))
            if isinstance(node, ast.FormattedValue) and node.format_spec is not None:
                self.fail("A formatted conversion should not replace the bit iterator.")


HAS_DISPLAY = bool(os.environ.get("DISPLAY")) or sys.platform in ("darwin", "win32")

@unittest.skipUnless(HAS_DISPLAY, "GUI checks require a desktop display or Xvfb.")
class GUITests(unittest.TestCase):
    def make_window(self, text):
        window = MorseGUI(text)
        self.addCleanup(self.safe_close, window)
        return window

    @staticmethod
    def safe_close(window):
        try:
            window.close()
        except Exception:
            # Some checks already close the real main loop.
            pass

    def test_actual_message_is_shown_without_changes(self):
        text = StreamingApp(FOLDER).read_text()
        window = self.make_window(text)
        window._MorseGUI__root.update_idletasks()
        self.assertEqual(window.get_text(), text)
        self.assertEqual(repr(window), "MorseGUI(characters=543)")
        self.assertEqual(str(window._MorseGUI__text_box.cget("state")), "disabled")

    def test_scrollbar_with_long_text(self):
        window = self.make_window("Example text\n" * 300)
        root = window._MorseGUI__root
        box = window._MorseGUI__text_box
        root.update_idletasks()
        self.assertLess(box.yview()[1], 1.0)
        box.yview_moveto(1.0)
        root.update_idletasks()
        self.assertGreater(box.yview()[0], 0.0)
        self.assertTrue(box.vbar.winfo_ismapped())

    def test_real_main_loop_starts_and_closes(self):
        window = self.make_window("A B ")
        observed = []
        root = window._MorseGUI__root
        root.after(40, lambda: observed.append(window.get_text()))
        root.after(80, window.close)
        window.run()
        self.assertEqual(observed, ["A B "])

    def test_driver_reaches_real_gui(self):
        expected = StreamingApp(FOLDER).read_text()
        observed = []
        original_run = MorseGUI.run

        def auto_close(window):
            observed.append(window.get_text())
            window._MorseGUI__root.after(60, window.close)
            original_run(window)

        with patch.object(MorseGUI, "run", auto_close):
            StreamingApp(FOLDER).run()
        self.assertEqual(observed, [expected])

    def test_standalone_entry_from_a_different_folder(self):
        # The wrapper schedules closing only; the script still creates its
        # own window and runs its real main loop with script-relative inputs.
        wrapper = '''
import runpy
import tkinter as tk
real_tk = tk.Tk
def auto_close_root(*args, **kwargs):
    root = real_tk(*args, **kwargs)
    root.after(100, root.destroy)
    return root
tk.Tk = auto_close_root
runpy.run_path(SCRIPT, run_name="__main__")
'''.replace("SCRIPT", repr(str(FOLDER / "streaming.py")))
        with tempfile.TemporaryDirectory() as other_folder:
            result = subprocess.run([sys.executable, "-c", wrapper], cwd=other_folder,
                                    text=True, capture_output=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
