"""SQLite connection, execution, transactions, and last results."""

import sqlite3


class CommandExecutor:
    """Execute generated SQL; do not choose tables or construct queries."""

    def __init__(self, database=":memory:", timeout=5.0):
        # SQL.ipynb, "Using SQLite from Python", supplies the connection pattern.
        # Using ClassDesign.ipynb's "Complete" structure, it becomes private state
        # here rather than a variable left over from another notebook cell.
        self.__settings = {"database": str(database), "timeout": timeout}
        self.__connection = sqlite3.connect(str(database), timeout=timeout)
        self.__results = []
        self.__columns = []
        self.__rowcount = 0
        self.__status = "Connected."
        self.__closed = False
        # The second dispatch dictionary is required by this assignment.
        self.exec_dispatch = {
            "SELECT": self._execute_select,
            "INSERT": self._execute_modify,
            "UPDATE": self._execute_modify,
            "DELETE": self._execute_modify,
            "CREATE": self._execute_ddl,
            "DROP": self._execute_ddl,
        }

    def execute(self, query_type, sql, parameters=()):
        self.__results, self.__columns = [], []
        self.__rowcount = 0
        self.__status = ""
        if self.__closed:
            raise ValueError("The database connection is closed.")
        query_type = query_type.upper()
        if query_type not in self.exec_dispatch:
            raise ValueError(f"Unsupported operation: {query_type}")
        if not sql.strip() or sql.lstrip().split()[0].upper() != query_type:
            raise ValueError("The SQL and dispatch operation do not match.")
        try:
            return self.exec_dispatch[query_type](query_type, sql, parameters)
        except (sqlite3.Error, ValueError, TypeError, OverflowError) as error:
            # SQL.ipynb, "Transactions", and SqliteDB.py's insert/update/delete helpers
            # use commit on success and rollback on error. Keep that pattern, but
            # let the GUI receive the error instead of only printing it.
            # A bad second row must undo the first row too. The batch commits only
            # after all rows succeed, and failed queries must not leave old results showing.
            self.__connection.rollback()
            self.__results, self.__columns = [], []
            self.__rowcount = 0
            self.__status = f"{query_type} failed; transaction rolled back: {error}"
            raise

    def _execute_select(self, query_type, sql, parameters):
        # DynamicSQL.ipynb, select_all(): keep execute followed by fetchall.
        # cursor.description is added so the headers describe this query's columns.
        cursor = self.__connection.execute(sql, parameters)
        self.__results = cursor.fetchall()
        self.__columns = [item[0] for item in cursor.description]
        self.__rowcount = len(self.__results)
        self.__status = f"SELECT returned {self.__rowcount} row(s)."
        return self.get_last_results()

    def _execute_modify(self, query_type, sql, parameters):
        # The batch operation comes from SqliteDB.py, insert_namedtuple_batch().
        # It still uses executemany with ordered tuples; UPDATE and DELETE use
        # execute. One shared handler is enough for these three operations.
        # The example starts with BEGIN. Here sqlite3's default write transaction
        # starts on the write instead, and commit still waits for the full batch.
        if query_type == "INSERT":
            cursor = self.__connection.executemany(sql, parameters)
        else:
            cursor = self.__connection.execute(sql, parameters)
        self.__connection.commit()
        self.__rowcount = cursor.rowcount
        self.__status = f"{query_type}: {self.__rowcount} row(s) affected."
        return self.__status

    def _execute_ddl(self, query_type, sql, parameters):
        # Based on SqliteDB.py's create_table()/delete_table() execution steps.
        # Return a status for CREATE and DROP; there are no result rows to fetch.
        self.__connection.execute(sql, parameters)
        self.__connection.commit()
        self.__status = f"{query_type} completed."
        return self.__status

    # Dunders.ipynb, Student.get_scores(): keep the copied-accessor pattern.
    # The GUI gets results and settings, not direct access to the connection.
    def get_connection_settings(self):
        return self.__settings.copy()

    def get_last_results(self):
        return self.__results.copy()

    def get_columns(self):
        return self.__columns.copy()

    def get_rowcount(self):
        return self.__rowcount

    def get_status(self):
        return self.__status

    def close(self):
        if not self.__closed:
            self.__connection.close()
            self.__closed = True

    # From Dunders.ipynb, GradingSystem.__iter__/__str__.
    # Use the last query's rows instead of students, without terminal color tracing.
    def __iter__(self):
        return iter(self.get_last_results())

    def __str__(self):
        return f"CommandExecutor({self.__settings['database']}): {self.__status}"
