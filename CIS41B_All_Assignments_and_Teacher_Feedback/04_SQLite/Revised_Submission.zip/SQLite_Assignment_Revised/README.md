# CIS 41B — SQLite Executor

## Run

Extract the whole folder and keep its files together. In a terminal in this folder:

```bash
python3 sqlite_gui.py
```

Use `python sqlite_gui.py` instead if that is the name of Python 3 on the computer.
The application uses the standard library and needs desktop Tkinter support. It does
not need pandas, Pillow, network access, a database server or image files.

The notebook works too. Keep it beside the CSVs, use a local desktop Python kernel and
run the cells in order. Its last code cell opens the window and remains busy until the
window closes. A remote kernel without a display will not show a local Tkinter window;
run the script on the desktop in that case.

## Try the full cycle

Press **Demo All Tables** and confirm. It runs CREATE, INSERT, SELECT checks, a one-row
UPDATE, a one-row DELETE and DROP for each loaded table. Then it recreates the table
and restores the source rows. This replaces earlier database edits in the session.
The CSV files are not changed.

The top display shows each generated SQL statement before execution and records the
executor's status. The lower display reports the completed cycles and shows the first table.

For individual operations, choose a table and press **Create Table → Insert Data → Select All**.
Take a **Row ID** from the results, select a column, enter a new value and press **Update Row**.
**Set NULL** writes a null value. A BLOB edit accepts hexadecimal text. **Delete Row** uses
the same ID; **Drop Table** removes the database table, not its CSV. Both ask for confirmation.

**Check Table** compares SQLite's actual column names, types, count and full contents
with the Python working rows. After a successful deletion, that expected count decreases.
The original CSV count is still shown for reference. Clicking **Insert Data** again on
a nonempty table is rejected, so a second click cannot duplicate the import.

**Load CSV** uses the same classes and buttons for another dictionary-backed table.
It does not require table or column names from the five supplied datasets.

## Files

`SQLite_Assignment.ipynb` contains the complete classes and the classroom references.
The notes explain what each example contributes, what changes and why, following
`ExampleAssignment.ipynb`, Step 8. The script version uses four modules:

| File | Job |
|---|---|
| `table_data.py` | Read CSV rows into dictionaries and keep their column metadata and inferred types. |
| `query_builder.py` | Generate SQL and the separate bound parameters. |
| `command_executor.py` | Own the connection, execute through dispatch, keep results and handle rollback. |
| `sqlite_gui.py` | Build the window and run the button, editing and validation workflow. |

The five original CSVs are included unchanged. `SOURCE_MAP.md` indexes the classroom
examples. The tests, `TEST_RESULTS.txt` and `gui_preview.png` are supporting checks,
not files the application needs to import.

## Data notes

| File | Data rows | Columns |
|---|---:|---:|
| CO2.csv | 731 | 7 |
| Dwarfs.csv | 13 | 3 |
| Elements.csv | 118 | 3 |
| Presidents.csv | 44 | 9 |
| Temperature.csv | 169 | 4 |

Temperature starts with three comment lines. The loader skips a single-field preamble
beginning with # followed by whitespace; it does not drop the real `#days` header.
Header spelling and spaces, including trailing spaces in Presidents, stay intact.
SQL quoting makes those names usable without renaming them.

Types are inferred from all nonempty values in a column, not just the first row.
A numeric column with decimal values becomes REAL. A mix of names and numeric-looking
identifiers stays TEXT. Empty fields become NULL; all-empty columns default to TEXT.
No historical facts, spellings or sentinel values such as `-1` are corrected.

As in `DynamicSQL.ipynb`, values use `?` parameters. The displayed SQL is exactly the
string passed to SQLite. Parameters are shown alongside it, not inserted into a
different query just for display.

## Database and checks

The default database is in memory, like the introductory SQL example. Closing the
window discards database edits. `CommandExecutor` also accepts a filename, and the tests
check that data persists in that case. The editor uses a hidden row ID rather than
adding a CSV column. A custom table that already uses all three names `rowid`, `_rowid_`
and `oid` is rejected by the GUI.

Run the test suite from this folder:

```bash
python3 -m unittest -v test_sqlite
```

GUI tests call real Tkinter buttons and are explicitly skipped if no display is available.
The recorded run uses a Linux virtual display. It does not establish that the window has
been tested on macOS or Windows; run it once on the computer used for submission.

Submit the notebook, all four application modules and the five CSVs together.
The source map, tests, log and screenshot can stay with them as supporting material.
