"""CSV rows and table metadata for Exercise SQLite."""

import csv
import math
from pathlib import Path


class TableData:
    """One table's source rows, column order, and inferred SQLite types."""

    def __init__(self, name, rows, columns=None):
        # ClassDesign.ipynb, "Complete": CaesarCipher.__init__ is the starting point.
        # The checks and private input copies stay. Table names and rows take the place
        # of cipher settings, since this object needs to hold data, not execute SQL.
        if not isinstance(name, str) or not name.strip() or "\x00" in name:
            raise ValueError("A table needs a nonempty name without NUL characters.")
        if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows):
            raise TypeError("Rows must be a list of dictionaries.")
        if columns is None:
            columns = list(rows[0]) if rows else []
        if not columns or any(not isinstance(c, str) or not c.strip() or "\x00" in c
                              for c in columns):
            raise ValueError("The CSV needs nonempty column names.")
        if len({c.lower() for c in columns}) != len(columns):
            raise ValueError("SQLite column names must be unique (ignoring case).")
        if any(set(row) != set(columns) for row in rows):
            raise ValueError("Every row must have the same column names.")
        allowed = (str, int, float, bytes, type(None))
        if any(not isinstance(v, allowed) for row in rows for v in row.values()):
            raise TypeError("Cell values must be text, numbers, bytes, or None.")

        self.__name = name
        self.__columns = list(columns)
        self.__types = {}
        for column in columns:
            self.__types[column] = self._infer_type([r[column] for r in rows])
        self.__rows = [
            {c: self._convert(row[c], self.__types[c]) for c in columns}
            for row in rows
        ]

    @classmethod
    def from_csv(cls, filename):
        # Based on Parsing.ipynb, "1b: csv.DictReader -- access fields by name".
        # The example opens a file and prints student fields. Here the same reader
        # collects all the dictionaries into a TableData, so no field names are fixed.
        with open(filename, newline="", encoding="utf-8-sig") as stream:
            reader = csv.reader(stream)
            headers = None
            for row in reader:
                # Temperature.csv has three # lines before its header. They are notes.
                # This extra check skips those single-field lines, not every line with #:
                # CO2 has a real column called '#days', and that must not disappear.
                if not row or all(not value.strip() for value in row):
                    continue
                first = row[0].lstrip()
                if len(row) == 1 and first.startswith("#") and (len(first) == 1 or first[1].isspace()):
                    continue
                headers = row
                break
            if headers is None:
                raise ValueError(f"{Path(filename).name}: no CSV header found.")
            rows = []
            for row in csv.DictReader(stream, fieldnames=headers):
                if None in row or any(value is None for value in row.values()):
                    raise ValueError(f"{Path(filename).name}: a row has the wrong width.")
                rows.append(row)
        return cls(Path(filename).stem, rows, headers)

    @staticmethod
    def _integer(value):
        if not isinstance(value, (str, int)):
            raise ValueError("Not an integer value.")
        number = int(value)
        if not -(2 ** 63) <= number < 2 ** 63:
            raise ValueError("Integer is outside SQLite's signed 64-bit range.")
        return number

    @classmethod
    def _infer_type(cls, values):
        # DynamicSQL.ipynb, "Inferring SQLite Types from Python Values", sqlite_type().
        # The type mapping stays, but its sample value is already typed. CSV values
        # are strings, so this version checks the whole column before converting it.
        # The first row is not enough: Dwarfs' Period(years) starts with integers
        # and later contains decimals.
        values = [v for v in values if v is not None and v != ""]
        if not values:
            return "TEXT"
        if all(isinstance(v, bytes) for v in values):
            return "BLOB"
        if any(isinstance(v, bytes) for v in values):
            raise ValueError("Binary and nonbinary values cannot share a column.")
        # Extra CSV check: '0012' stays text. Converting it would lose the zeros.
        for value in values:
            if isinstance(value, str):
                digits = value.strip().lstrip("+-")
                if digits.isdigit() and len(digits) > 1 and digits.startswith("0"):
                    return "TEXT"
                if digits.isdigit() and not -(2 ** 63) <= int(value) < 2 ** 63:
                    return "TEXT"
            elif isinstance(value, int) and not -(2 ** 63) <= value < 2 ** 63:
                return "TEXT"
        try:
            for value in values:
                cls._integer(value)
            return "INTEGER"
        except (ValueError, TypeError):
            pass
        try:
            if all(math.isfinite(float(v)) for v in values):
                return "REAL"
        except (ValueError, TypeError, OverflowError):
            pass
        return "TEXT"

    @classmethod
    def _convert(cls, value, column_type):
        # This conversion step is new; the notebook's namedtuples already had types.
        # Empty fields become None for SQL NULL. Leave other text alone, including
        # spaces and spellings. Loading the data is not the same as correcting it.
        if value is None or value == "":
            return None
        if column_type == "INTEGER":
            return cls._integer(value)
        if column_type == "REAL":
            result = float(value)
            if not math.isfinite(result):
                raise ValueError("A REAL value must be finite.")
            return result
        if column_type == "BLOB":
            if not isinstance(value, bytes):
                raise ValueError("A BLOB value must be bytes.")
            return value
        return str(value)

    def convert_input(self, column, text):
        if column not in self.__types:
            raise ValueError("Choose a column from the selected table.")
        if self.__types[column] == "BLOB":
            # New for the editor: accept hex text when the stored value is bytes.
            return bytes.fromhex(text)
        return self._convert(text, self.__types[column])

    # Dunders.ipynb's Student.get_scores() returns a copy, as do the accessors
    # in ClassDesign.ipynb, "Complete". The same idea protects the source rows
    # here. A GUI edit should not also change the data used to check that edit.
    def get_name(self):
        return self.__name

    def get_columns(self):
        return self.__columns.copy()

    def get_types(self):
        return self.__types.copy()

    def get_rows(self):
        return [row.copy() for row in self.__rows]

    def get_row_key(self):
        # New for selecting a row in the GUI. Two rows may have the same values,
        # and these files do not all have a 'name' column. Use an available hidden
        # SQLite row ID instead of adding a field to the original CSV schema.
        names = {column.lower() for column in self.__columns}
        for key in ("rowid", "_rowid_", "oid"):
            if key not in names:
                return key
        raise ValueError("This GUI needs one unshadowed rowid, _rowid_, or oid name.")

    # From Dunders.ipynb, GradingSystem.__iter__, __len__ and __str__.
    # Rows replace students. The colored trace prints are not needed here.
    def __iter__(self):
        return iter(self.get_rows())

    def __len__(self):
        return len(self.__rows)

    def __str__(self):
        return f"{self.__name}: {len(self)} rows, {len(self.__columns)} columns"

    def __eq__(self, other):
        # ClassDesign.ipynb, "Complete", CaesarCipher.__eq__: compare stored state.
        # Here that means the table name, columns, types and rows, not cipher settings.
        if not isinstance(other, TableData):
            return NotImplemented
        return (self.__name == other.__name and self.__columns == other.__columns
                and self.__types == other.__types and self.__rows == other.__rows)
