# Classroom references

The table points to the examples used for each part of the program. The corresponding
comments sit beside the adapted methods, and the notebook explains the larger changes
before each class.

| Part of this solution | Classroom source | Kept / changed |
|---|---|---|
| Class structure | `ClassDesign.ipynb`, **Complete**, `CaesarCipher` (cell 14); `ExampleAssignment.ipynb`, **Step 8** (cells 14-15) | The constructor, accessors, helpers and public methods stay. Cipher behavior is replaced by CSV loading, SQL construction, execution and the window, each in its own class. |
| CSV loading | `Parsing.ipynb`, **1 — CSV Reading & Writing**, **1b: csv.DictReader — access fields by name** (cell 7) | Use the same file context manager and DictReader. Collect every row instead of printing a few student fields; later code needs the whole table. |
| Type inference | `DynamicSQL.ipynb`, **Inferring SQLite Types from Python Values**, `sqlite_type()` (cell 5) | Keep the Python-to-SQLite type choices. CSV cells start as strings, so check all nonempty values in each column before converting them. |
| CREATE | `DynamicSQL.ipynb`, **Building a CREATE TABLE Statement Dynamically**, `create_table()` (cell 7) | Join column definitions as in the example. Dictionary keys replace namedtuple fields, and returning the SQL lets the GUI show it before execution. |
| INSERT | `DynamicSQL.ipynb`, **Building an INSERT Statement Dynamically**, `insert_row()` (cell 9); `SqliteDB.py`, `insert_namedtuple_batch()` | Keep one ? per column and a consistent field order. Build tuples from dictionary values in that order; the executor inserts the batch. |
| UPDATE / DELETE | `DynamicSQL.ipynb`, the corresponding **Building ... Dynamically** sections, `update_row()` / `delete_row()` (cells 11 / 13) | Keep the SET fragments and bound WHERE values. The lookup field now comes from a dictionary, since the five CSVs do not share a name column. |
| SELECT / DROP | `DynamicSQL.ipynb`, **Building a SELECT Statement Dynamically**, `select_all()` (cell 15); `SqliteDB.py`, `delete_table()` | Keep a generated table name, fetchall and DROP IF EXISTS. Building the statement and running it are separate jobs now. |
| Connection / rollback | `SQL.ipynb`, **Using SQLite from Python** (cells 3-4), **Transactions** (cells 28-29); `SqliteDB.py`, modification helpers | Keep connect, execute, commit and rollback. Put the connection in CommandExecutor, and pass failures back to the GUI rather than only printing them. |
| Accessors and dunders | `Dunders.ipynb`, **Student Class** and **GradingSystem Class** (cells 4-7); `ClassDesign.ipynb`, **Complete** | Copied accessors protect stored rows. Iteration yields rows instead of students, and equality compares TableData snapshots rather than student names or cipher settings. |
| GUI layout / events | `Tkinter.ipynb`, `TkinterShowcase.__init__`, `build_textbox_tab()`, `build_button_tab()`, `build_menu_tab()` (code in cell 2, explanations in cells 4/8/14) | Keep frames, ScrolledText and callbacks. Two displays replace the showcase tabs; the selectors take their options from the loaded table metadata. |

Cell numbers count all cells from 1, not Jupyter execution numbers. Section and method
names are the main references.

## Additions for this assignment

The two dispatch dictionaries come from the SQLite assignment's required design.
The existing notebook functions are separated into a builder and an executor to make
that design work.

CSV preamble handling, whole-column inference, identifier quoting, general WHERE
dictionaries and hidden-row-ID selection are added here. So are the typed editor,
schema/count/content checks and all-table demo. The comments distinguish these additions
from the classroom methods they use. The test suite is separate verification code.

The notebook contains the full class definitions. The four Python modules contain
the same classes, including the method-level explanations.
