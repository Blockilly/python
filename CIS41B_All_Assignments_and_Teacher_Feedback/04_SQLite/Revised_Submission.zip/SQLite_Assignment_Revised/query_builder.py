"""Generate statements without opening or changing a database."""


class QueryBuilder:
    """Build one SQL string and its matching bound parameters."""

    def __init__(self):
        # DynamicSQL.ipynb has separate CRUD functions. This class groups their
        # SQL-building work; the dispatch dictionary is added for this assignment.
        # It picks a method. Nothing is sent to SQLite here.
        self.dispatch = {
            "CREATE": self.build_create,
            "INSERT": self.build_insert,
            "SELECT": self.build_select,
            "UPDATE": self.build_update,
            "DELETE": self.build_delete,
            "DROP": self.build_drop,
        }
        self.__parameters = ()
        self.__last_sql = ""

    def build(self, query_type, **kwargs):
        self.__parameters = ()
        self.__last_sql = ""
        query_type = query_type.upper()
        if query_type not in self.dispatch:
            raise ValueError(f"Unsupported operation: {query_type}")
        self.__last_sql = self.dispatch[query_type](**kwargs)
        return self.__last_sql

    @staticmethod
    def _quote(name):
        # Extra handling around the notebook's f-strings: headers such as '#days'
        # and 'Period(years)' need quoted names, not renamed columns. This helper
        # is for names only. Row values still go through ? parameters.
        if not isinstance(name, str) or not name.strip() or "\x00" in name:
            raise ValueError("Invalid SQL identifier.")
        return '"' + name.replace('"', '""') + '"'

    def _where(self, conditions):
        # Based on DynamicSQL.ipynb's update_row()/delete_row(): WHERE name = ?.
        # Use dictionary keys instead of the fixed name field so other tables work.
        # The IS NULL case is added because '= NULL' will not match an empty value.
        parts, values = [], []
        for column, value in conditions.items():
            if value is None:
                parts.append(f"{self._quote(column)} IS NULL")
            else:
                parts.append(f"{self._quote(column)} = ?")
                values.append(value)
        return " AND ".join(parts), values

    def build_create(self, table, column_types):
        # From DynamicSQL.ipynb, "Building a CREATE TABLE Statement Dynamically",
        # create_table(). Keep the joined field/type fragments, using dictionary
        # metadata instead of _fields and getattr. Return the SQL without running it;
        # the GUI needs to show it first.
        # The example also adds an id column. This version does not: the columns
        # should match the CSV, and the editor can use SQLite's hidden rowid.
        if not column_types:
            raise ValueError("A table needs columns.")
        definitions = []
        for column, kind in column_types.items():
            if kind not in {"TEXT", "INTEGER", "REAL", "BLOB"}:
                raise ValueError(f"Unsupported column type: {kind}")
            definitions.append(f"{self._quote(column)} {kind}")
        return f"CREATE TABLE IF NOT EXISTS {self._quote(table)} ({', '.join(definitions)});"

    def build_insert(self, table, rows):
        # DynamicSQL.ipynb, "Building an INSERT Statement Dynamically", insert_row(),
        # and SqliteDB.py, insert_namedtuple_batch(). Keep one ? for each field.
        # Dictionary keys replace _fields. Every row is then read in that one column
        # order, even if a later dictionary was built in a different order.
        if not rows or not all(isinstance(row, dict) for row in rows):
            raise ValueError("INSERT needs a nonempty list of dictionaries.")
        columns = list(rows[0])
        if not columns or any(set(row) != set(columns) for row in rows):
            raise ValueError("INSERT rows must have matching columns.")
        fields = ", ".join(self._quote(c) for c in columns)
        placeholders = ", ".join(["?"] * len(columns))
        self.__parameters = [tuple(row[c] for c in columns) for row in rows]
        return f"INSERT INTO {self._quote(table)} ({fields}) VALUES ({placeholders});"

    def build_select(self, table, columns=None, where=None, order_by=None,
                     count=False, schema=False):
        # Based on DynamicSQL.ipynb, "Building a SELECT Statement Dynamically",
        # select_all(). The table name is still supplied at runtime. Column choices
        # and dictionary filters are added here; ordering follows SQL.ipynb's
        # "Sorting and Limiting Results", without fixing the sort column to grade.
        values = []
        if schema:
            # New schema check. Ask SQLite for its actual column names and types.
            # Using the CSV metadata again would only compare our expected schema
            # with itself, which would not catch a bad table definition.
            columns, order_by = ["name", "type"], ["cid"]
            source = "pragma_table_info(?)"
            values.append(table)
        else:
            source = self._quote(table)
        if count:
            fields = "COUNT(*)"
        elif columns:
            fields = ", ".join(self._quote(c) for c in columns)
        else:
            fields = "*"
        sql = f"SELECT {fields} FROM {source}"
        if where:
            condition, params = self._where(where)
            sql += f" WHERE {condition}"
            values.extend(params)
        if order_by:
            sql += " ORDER BY " + ", ".join(self._quote(c) for c in order_by)
        self.__parameters = tuple(values)
        return sql + ";"

    def build_update(self, table, changes, where):
        # DynamicSQL.ipynb, "Building an UPDATE Statement Dynamically", update_row().
        # Keep the SET fragments and parameter order: new values first, lookup
        # values after. Both sets of field names now come from dictionaries.
        if not changes or not where:
            raise ValueError("UPDATE needs changes and a nonempty row condition.")
        assignments = ", ".join(f"{self._quote(c)} = ?" for c in changes)
        condition, params = self._where(where)
        self.__parameters = tuple(changes.values()) + tuple(params)
        return f"UPDATE {self._quote(table)} SET {assignments} WHERE {condition};"

    def build_delete(self, table, where):
        # From DynamicSQL.ipynb, "Building a DELETE Statement Dynamically", delete_row().
        # The lookup is now a dictionary rather than a fixed name. The empty-condition
        # check is extra. Delete Row should not silently become delete every row.
        if not where:
            raise ValueError("DELETE needs a nonempty row condition.")
        condition, params = self._where(where)
        self.__parameters = tuple(params)
        return f"DELETE FROM {self._quote(table)} WHERE {condition};"

    def build_drop(self, table):
        # SqliteDB.py, delete_table(): keep DROP TABLE IF EXISTS.
        # Only return the statement here; CommandExecutor handles the connection.
        return f"DROP TABLE IF EXISTS {self._quote(table)};"

    # The accessors follow ClassDesign.ipynb, "Complete".
    # Keep parameters separate from the SQL so display and execution use the same string.
    def get_parameters(self):
        return self.__parameters.copy() if isinstance(self.__parameters, list) else self.__parameters

    def get_last_sql(self):
        return self.__last_sql

    def __str__(self):
        return "QueryBuilder: " + ", ".join(self.dispatch)
