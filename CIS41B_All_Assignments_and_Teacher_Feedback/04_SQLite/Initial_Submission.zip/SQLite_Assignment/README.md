# CIS 41B — SQLite Executor

## Files

`SQLite_Assignment.ipynb` contains the complete class definitions, classroom references,
and the keep/change/add explanations. It follows the adaptation format shown in
`ExampleAssignment.ipynb`, rather than importing a completed script into an otherwise empty notebook.

The same class code is supplied as four Python modules:

| File | Responsibility |
|---|---|
| `table_data.py` | `TableData`: CSV -> list of dictionaries, column metadata and type inference |
| `query_builder.py` | `QueryBuilder`: dynamically generated SQL and bound parameters |
| `command_executor.py` | `CommandExecutor`: connection, execution dispatch, results and rollback |
| `sqlite_gui.py` | `SQLiteGUI`: window, operation buttons, editing and validation |

The five original CSV files are included unchanged. `SOURCE_MAP.md` is a compact index
of the notebook references. `test_sqlite.py`, `TEST_RESULTS.txt` and `gui_preview.png`
provide the checks and an actual GUI screenshot.

## Run

Extract the whole folder first. From a terminal in this folder:

```bash
python3 sqlite_gui.py
```

On a system where Python 3 is named `python`, use `python sqlite_gui.py`.
The application uses only Python's standard library, with Tkinter desktop support.
It does not need pandas, Pillow, network access, a database server, or image files.

For the notebook, keep it beside the CSVs, use a local desktop Python kernel,
and run the cells in order. The final code cell opens the same GUI. It stays busy
until the window closes. A remote notebook kernel without a display cannot show a
local Tkinter window; use the Python script on a desktop in that situation.

## Demonstrate the requirements

Press **Demo All Tables**, then confirm. For each loaded table it runs creation,
insertion, SELECT validation, a one-row update, a one-row deletion and a table drop.
It checks each stage, recreates the table, and restores the source rows. It replaces
any database edits made earlier in that session; the CSV files are never changed.
The SQL log shows the generated statements before execution and the executor statuses.
The final results pane reports the completed cycles and displays the first table.

For individual operations, choose a table and use **Create Table → Insert Data → Select All**.
The results include a **Row ID**. To update, enter that ID, select a column, type a value,
and press **Update Row**. **Set NULL** explicitly writes a null value. For BLOB columns,
the editor accepts hexadecimal text. **Delete Row** uses the same ID. **Drop Table** removes
the database table, not its CSV. Delete and Drop ask for confirmation.

**Check Table** independently checks database column names/types, row count and complete
SELECT contents against the Python working rows. The original CSV row count is also shown.
After a successful deletion the current expected count decreases; it is not incorrectly
compared with the unchanged source-file count. Repeating Insert Data on a nonempty table
is rejected so the import is not accidentally duplicated.

**Load CSV** accepts an additional CSV using the same classes, buttons and dynamic SQL.
Table and column names are not restricted to the five exercise datasets.

## Data handling

| Supplied file | Data rows | Columns |
|---|---:|---:|
| CO2.csv | 731 | 7 |
| Dwarfs.csv | 13 | 3 |
| Elements.csv | 118 | 3 |
| Presidents.csv | 44 | 9 |
| Temperature.csv | 169 | 4 |

Temperature has three introductory comment lines before its header. A single-field
preamble beginning with `#` followed by whitespace is skipped; the actual `#days` header
is retained. Header spelling and spaces are preserved, including trailing spaces in Presidents.
SQL identifier quoting makes those names usable without renaming them.

Types are inferred from all nonempty values in each column. A numeric column containing
any decimal value uses REAL; mixed names/numeric-looking identifiers remain TEXT. Empty
fields become NULL and all-empty columns default to TEXT. The program does not update
historical facts, correct spellings, or reinterpret source values such as `-1`.

SQL uses generated identifiers and `?` parameter placeholders, as in DynamicSQL.ipynb.
The displayed SQL is exactly what is passed to SQLite; parameters are shown separately,
not interpolated into a second display-only query.

## Database and tests

The GUI uses an in-memory database by default, matching the introductory SQL example.
Closing the window discards database edits. `CommandExecutor` also accepts a filename;
its persistent-database behavior is tested separately. The ordinary rowid-table design
lets the GUI target a single row without adding a column to the CSV schema. A custom table
that shadows all of `rowid`, `_rowid_` and `oid` is rejected by the GUI rather than guessed at.

Run the additional test suite with:

```bash
python3 -m unittest -v test_sqlite
```

GUI tests invoke actual Tkinter button callbacks. They are explicitly skipped when no
display is available. The recorded test run used a Linux virtual display; it is not a
claim that macOS or Windows has been tested. Check the window once on the submission computer.

For submission, keep the notebook, all four application modules and the five CSVs together.
The source map, tests, log and screenshot are supporting evidence, not extra runtime dependencies.
