"""SQLite connection, execution, transactions, and last results."""

import sqlite3


class CommandExecutor:
    """Execute generated SQL; do not choose tables or construct queries."""

    def __init__(self, database=":memory:", timeout=5.0):
        # Adapted from SQL.ipynb, "Using SQLite from Python", and ClassDesign.ipynb,
        # "Complete". The connection is now private instance state rather than
        # a notebook variable. Each GUI receives one executor with its own settings.
        self.__settings = {"database": str(database), "timeout": timeout}
        self.__connection = sqlite3.connect(str(database), timeout=timeout)
        self.__results = []
        self.__columns = []
        self.__rowcount = 0
        self.__status = "Connected."
        self.__closed = False
        # Added to meet the assignment's dictionary-based execution requirement.
        self.exec_dispatch = {
            "SELECT": self._execute_select,
            "INSERT": self._execute_modify,
            "UPDATE": self._execute_modify,
            "DELETE": self._execute_modify,
            "CREATE": self._execute_ddl,
            "DROP": self._execute_ddl,
        }

    def execute(self, query_type, sql, parameters=()):
        self.__results, self.__columns = [], []
        self.__rowcount = 0
        self.__status = ""
        if self.__closed:
            raise ValueError("The database connection is closed.")
        query_type = query_type.upper()
        if query_type not in self.exec_dispatch:
            raise ValueError(f"Unsupported operation: {query_type}")
        if not sql.strip() or sql.lstrip().split()[0].upper() != query_type:
            raise ValueError("The SQL and dispatch operation do not match.")
        try:
            return self.exec_dispatch[query_type](query_type, sql, parameters)
        except (sqlite3.Error, ValueError, TypeError, OverflowError) as error:
            # Adapted from SQL.ipynb, "Transactions", and SqliteDB.py's
            # insert/update/delete helpers. Keep rollback on failure, but raise
            # the error for the GUI instead of printing and pretending success.
            # One INSERT batch commits only after every row succeeds; a bad later
            # row must not leave the earlier rows inserted. Clear stale results too.
            self.__connection.rollback()
            self.__results, self.__columns = [], []
            self.__rowcount = 0
            self.__status = f"{query_type} failed; transaction rolled back: {error}"
            raise

    def _execute_select(self, query_type, sql, parameters):
        # Adapted from DynamicSQL.ipynb, select_all(): execute then fetchall.
        # Added cursor.description so GUI headers come from the returned query.
        cursor = self.__connection.execute(sql, parameters)
        self.__results = cursor.fetchall()
        self.__columns = [item[0] for item in cursor.description]
        self.__rowcount = len(self.__results)
        self.__status = f"SELECT returned {self.__rowcount} row(s)."
        return self.get_last_results()

    def _execute_modify(self, query_type, sql, parameters):
        # Adapted from SqliteDB.py, insert_namedtuple_batch(): executemany with
        # ordered row tuples. UPDATE/DELETE use execute as in their notebook
        # helpers. Shared dispatch avoids repeating the transaction code.
        # Unlike the example's explicit BEGIN, sqlite3's default write transaction
        # starts the batch here. The commit still occurs only after the whole batch.
        if query_type == "INSERT":
            cursor = self.__connection.executemany(sql, parameters)
        else:
            cursor = self.__connection.execute(sql, parameters)
        self.__connection.commit()
        self.__rowcount = cursor.rowcount
        self.__status = f"{query_type}: {self.__rowcount} row(s) affected."
        return self.__status

    def _execute_ddl(self, query_type, sql, parameters):
        # Adapted from SqliteDB.py, create_table()/delete_table(). These methods
        # return a status rather than rows, so keep them separate from SELECT.
        self.__connection.execute(sql, parameters)
        self.__connection.commit()
        self.__status = f"{query_type} completed."
        return self.__status

    # Adapted from Dunders.ipynb, Student.get_scores(): expose copies, not
    # mutable result storage or a connection that could bypass this executor.
    def get_connection_settings(self):
        return self.__settings.copy()

    def get_last_results(self):
        return self.__results.copy()

    def get_columns(self):
        return self.__columns.copy()

    def get_rowcount(self):
        return self.__rowcount

    def get_status(self):
        return self.__status

    def close(self):
        if not self.__closed:
            self.__connection.close()
            self.__closed = True

    # Adapted from Dunders.ipynb, GradingSystem.__iter__/__str__.
    # Iterate over query rows instead of students; no colored terminal traces.
    def __iter__(self):
        return iter(self.get_last_results())

    def __str__(self):
        return f"CommandExecutor({self.__settings['database']}): {self.__status}"
