"""Generate statements without opening or changing a database."""


class QueryBuilder:
    """Build one SQL string and its matching bound parameters."""

    def __init__(self):
        # New class wrapper for DynamicSQL.ipynb's separate CRUD functions.
        # The dispatch dictionary comes from this assignment's required design,
        # not from a claim that the notebook already contained this class.
        self.dispatch = {
            "CREATE": self.build_create,
            "INSERT": self.build_insert,
            "SELECT": self.build_select,
            "UPDATE": self.build_update,
            "DELETE": self.build_delete,
            "DROP": self.build_drop,
        }
        self.__parameters = ()
        self.__last_sql = ""

    def build(self, query_type, **kwargs):
        self.__parameters = ()
        self.__last_sql = ""
        query_type = query_type.upper()
        if query_type not in self.dispatch:
            raise ValueError(f"Unsupported operation: {query_type}")
        self.__last_sql = self.dispatch[query_type](**kwargs)
        return self.__last_sql

    @staticmethod
    def _quote(name):
        # Added to the notebook's f-string pattern: CSV headers include spaces,
        # parentheses and '#days'. Keep their exact names and quote identifiers.
        # Values use ? parameters instead; they are not pasted into SQL text.
        if not isinstance(name, str) or not name.strip() or "\x00" in name:
            raise ValueError("Invalid SQL identifier.")
        return '"' + name.replace('"', '""') + '"'

    def _where(self, conditions):
        # Adapted from DynamicSQL.ipynb's UPDATE/DELETE WHERE name = ? pattern.
        # Replaced the fixed name field with dictionary keys so all CSVs work.
        # Added IS NULL because '= NULL' would not find an empty CSV value.
        parts, values = [], []
        for column, value in conditions.items():
            if value is None:
                parts.append(f"{self._quote(column)} IS NULL")
            else:
                parts.append(f"{self._quote(column)} = ?")
                values.append(value)
        return " AND ".join(parts), values

    def build_create(self, table, column_types):
        # Adapted from DynamicSQL.ipynb, "Building a CREATE TABLE Statement
        # Dynamically", create_table(). Kept joining field/type fragments.
        # Replaced _fields/getattr with dict metadata. Removed execute/commit:
        # the GUI must receive this SQL before CommandExecutor runs it.
        # Removed the notebook's added id column so schema checks match the CSV
        # exactly. The GUI uses SQLite's hidden rowid without changing the schema.
        if not column_types:
            raise ValueError("A table needs columns.")
        definitions = []
        for column, kind in column_types.items():
            if kind not in {"TEXT", "INTEGER", "REAL", "BLOB"}:
                raise ValueError(f"Unsupported column type: {kind}")
            definitions.append(f"{self._quote(column)} {kind}")
        return f"CREATE TABLE IF NOT EXISTS {self._quote(table)} ({', '.join(definitions)});"

    def build_insert(self, table, rows):
        # Adapted from DynamicSQL.ipynb, "Building an INSERT Statement
        # Dynamically", insert_row(), and SqliteDB.py's insert_namedtuple_batch.
        # Kept one ? per field. Replaced tuple._fields with dict keys, and read
        # every row in that same key order so reordered dicts cannot swap values.
        if not rows or not all(isinstance(row, dict) for row in rows):
            raise ValueError("INSERT needs a nonempty list of dictionaries.")
        columns = list(rows[0])
        if not columns or any(set(row) != set(columns) for row in rows):
            raise ValueError("INSERT rows must have matching columns.")
        fields = ", ".join(self._quote(c) for c in columns)
        placeholders = ", ".join(["?"] * len(columns))
        self.__parameters = [tuple(row[c] for c in columns) for row in rows]
        return f"INSERT INTO {self._quote(table)} ({fields}) VALUES ({placeholders});"

    def build_select(self, table, columns=None, where=None, order_by=None,
                     count=False, schema=False):
        # Adapted from DynamicSQL.ipynb, "Building a SELECT Statement
        # Dynamically", select_all(). Kept a generated table name. Added column
        # selection and dictionary filters; ORDER BY follows SQL.ipynb,
        # "Sorting and Limiting Results", but takes metadata instead of 'grade'.
        values = []
        if schema:
            # New validation query: SQLite's table-valued pragma reports actual
            # column names/types. This is SQLite metadata, not a second schema
            # copied from the CSV, so mismatches can really be detected.
            columns, order_by = ["name", "type"], ["cid"]
            source = "pragma_table_info(?)"
            values.append(table)
        else:
            source = self._quote(table)
        if count:
            fields = "COUNT(*)"
        elif columns:
            fields = ", ".join(self._quote(c) for c in columns)
        else:
            fields = "*"
        sql = f"SELECT {fields} FROM {source}"
        if where:
            condition, params = self._where(where)
            sql += f" WHERE {condition}"
            values.extend(params)
        if order_by:
            sql += " ORDER BY " + ", ".join(self._quote(c) for c in order_by)
        self.__parameters = tuple(values)
        return sql + ";"

    def build_update(self, table, changes, where):
        # Adapted from DynamicSQL.ipynb, "Building an UPDATE Statement
        # Dynamically", update_row(). Kept SET fragments and the parameter order
        # (new values, then lookup values). Both SET and WHERE fields are dynamic.
        if not changes or not where:
            raise ValueError("UPDATE needs changes and a nonempty row condition.")
        assignments = ", ".join(f"{self._quote(c)} = ?" for c in changes)
        condition, params = self._where(where)
        self.__parameters = tuple(changes.values()) + tuple(params)
        return f"UPDATE {self._quote(table)} SET {assignments} WHERE {condition};"

    def build_delete(self, table, where):
        # Adapted from DynamicSQL.ipynb, "Building a DELETE Statement
        # Dynamically", delete_row(). Added the nonempty condition check to
        # prevent the Delete Row button from accidentally deleting the table's data.
        if not where:
            raise ValueError("DELETE needs a nonempty row condition.")
        condition, params = self._where(where)
        self.__parameters = tuple(params)
        return f"DELETE FROM {self._quote(table)} WHERE {condition};"

    def build_drop(self, table):
        # Adapted from SqliteDB.py, delete_table(). Kept DROP TABLE IF EXISTS,
        # but moved connection handling to CommandExecutor like the other builders.
        return f"DROP TABLE IF EXISTS {self._quote(table)};"

    # ClassDesign.ipynb, "Complete": keep access to state through methods.
    # SQL stays unchanged for display; parameter values travel separately.
    def get_parameters(self):
        return self.__parameters.copy() if isinstance(self.__parameters, list) else self.__parameters

    def get_last_sql(self):
        return self.__last_sql

    def __str__(self):
        return "QueryBuilder: " + ", ".join(self.dispatch)
