"""GUI driver for the dynamic SQLite assignment. Run: python sqlite_gui.py"""

# Adapted from Tkinter.ipynb's import cell. Kept tkinter/ttk/ScrolledText.
# Removed PIL, threading and time: this app has no images or progress threads.
# Added filedialog for loading CSVs; no requests, pandas, or notebook display calls.
import sqlite3
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
from pathlib import Path

from table_data import TableData
from query_builder import QueryBuilder
from command_executor import CommandExecutor


class SQLiteGUI:
    """Own the window and drive TableData -> QueryBuilder -> CommandExecutor."""

    def __init__(self, data_directory, builder=None, executor=None):
        # Adapted from Tkinter.ipynb, TkinterShowcase.__init__, and the Complete
        # class pattern in ClassDesign.ipynb. Keep layout in class methods.
        # Replaced ttk.Frame inheritance with a GUI owner; child ttk.Frames
        # still handle layout. Root creation and shutdown now belong to this class.
        # Unlike the showcase's external master, this class creates its window.
        # Dependencies are passed in or created here, not taken from earlier cells.
        self._builder = QueryBuilder() if builder is None else builder
        self._executor = CommandExecutor() if executor is None else executor
        self._tables = {}
        self._expected = {}
        self._last_error = None
        self._root = tk.Tk()
        self._root.title("SQLite Executor - Dynamic SQL")
        self._root.geometry("1180x820")
        self._root.minsize(940, 680)
        self._root.protocol("WM_DELETE_WINDOW", self.close)
        self._build_widgets()
        self.load_paths(sorted(Path(data_directory).glob("*.csv")))

    def _build_widgets(self):
        # Adapted from Tkinter.ipynb, build_textbox_tab()/build_button_tab().
        # Kept frame-based layout, pack(expand=True, fill='both') and callbacks.
        # Replaced showcase tabs with two permanent displays: SQL and results.
        # Removed image/radio/calculator tabs because they do not drive this task.
        controls = ttk.Frame(self._root, padding=10)
        controls.pack(fill="x")
        self._table_var = tk.StringVar(self._root)
        self._row_var = tk.StringVar(self._root, value="1")
        self._column_var = tk.StringVar(self._root)
        self._value_var = tk.StringVar(self._root)
        self._null_var = tk.BooleanVar(self._root, value=False)
        self._info_var = tk.StringVar(self._root)
        self._buttons = {}

        top = ttk.Frame(controls)
        top.pack(fill="x")
        ttk.Label(top, text="Table:").pack(side="left")
        # Added readonly selectors using the StringVar/selection callback idea
        # from Tkinter.ipynb, build_menu_tab(). Their choices come from metadata,
        # not fixed planet fields. Combobox itself is a new widget in this version.
        self._table_menu = ttk.Combobox(top, textvariable=self._table_var,
                                        state="readonly", width=22)
        self._table_menu.pack(side="left", padx=6)
        self._table_menu.bind("<<ComboboxSelected>>", self._table_changed)
        self._add_button(top, "Load CSV", self.open_files)
        self._add_button(top, "Check Table", self.check_table)
        self._add_button(top, "Demo All Tables", self.demo_all)
        ttk.Label(controls, textvariable=self._info_var).pack(anchor="w", pady=6)

        actions = ttk.Frame(controls)
        actions.pack(fill="x")
        for label, method in [("Create Table", self.create_table),
                              ("Insert Data", self.insert_data),
                              ("Select All", self.select_all),
                              ("Update Row", self.update_row),
                              ("Delete Row", self.delete_row),
                              ("Drop Table", self.drop_table)]:
            self._add_button(actions, label, method)

        editor = ttk.Frame(controls)
        editor.pack(fill="x", pady=(10, 0))
        ttk.Label(editor, text="Row ID:").pack(side="left")
        ttk.Entry(editor, textvariable=self._row_var, width=7).pack(side="left", padx=5)
        ttk.Label(editor, text="Update column:").pack(side="left")
        self._column_menu = ttk.Combobox(editor, textvariable=self._column_var,
                                         state="readonly", width=22)
        self._column_menu.pack(side="left", padx=5)
        self._column_menu.bind("<<ComboboxSelected>>", self._fill_value)
        ttk.Label(editor, text="New value:").pack(side="left")
        ttk.Entry(editor, textvariable=self._value_var, width=28).pack(side="left", padx=5)
        ttk.Checkbutton(editor, text="Set NULL", variable=self._null_var).pack(side="left")
        ttk.Label(controls, text="Row ID is SQLite's hidden row identifier, not a CSV column. "
                  "For BLOB edits, enter hexadecimal text.").pack(anchor="w", pady=(5, 0))

        self._sql_box = self._make_display("SQL generated by QueryBuilder (parameters shown separately)", 11)
        self._results_box = self._make_display("Results returned by CommandExecutor / validation", 16)

    def _add_button(self, parent, label, method):
        button = ttk.Button(parent, text=label, command=lambda: self._handle(method))
        button.pack(side="left", padx=(0, 5))
        self._buttons[label] = button

    def _make_display(self, title, height):
        frame = ttk.LabelFrame(self._root, text=title, padding=5)
        frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        # Adapted from build_textbox_tab(): keep ScrolledText, but use a fixed
        # font, no wrapping and horizontal scrolling for wide CSV tables.
        box = scrolledtext.ScrolledText(frame, height=height, wrap="none",
                                         font="TkFixedFont", state="disabled")
        bar = ttk.Scrollbar(frame, orient="horizontal", command=box.xview)
        box.configure(xscrollcommand=bar.set)
        bar.pack(side="bottom", fill="x")
        box.pack(fill="both", expand=True)
        return box

    @staticmethod
    def _write(box, text, append=False):
        # New helper: readonly displays may be changed by callbacks, not by typing.
        box.configure(state="normal")
        if not append:
            box.delete("1.0", tk.END)
        box.insert(tk.END, text)
        box.configure(state="disabled")
        if append:
            box.see(tk.END)

    def _show(self, message, rows=None, columns=None):
        text = message + "\n"
        if rows is not None:
            values = [["NULL" if v is None else v.hex() if isinstance(v, bytes)
                       else str(v) for v in row] for row in rows]
            columns = columns or self._executor.get_columns()
            widths = [max([len(str(c))] + [len(r[i]) for r in values])
                      for i, c in enumerate(columns)]
            lines = [" | ".join(str(c).ljust(w) for c, w in zip(columns, widths)),
                     "-+-".join("-" * w for w in widths)]
            lines.extend(" | ".join(v.ljust(w) for v, w in zip(r, widths)) for r in values)
            text += "\n" + "\n".join(lines)
        self._write(self._results_box, text)

    def _handle(self, method):
        self._last_error = None
        try:
            method()
        except (sqlite3.Error, OSError, ValueError, TypeError, OverflowError) as error:
            self._last_error = str(error)
            self._show(f"Operation not completed: {error}\nSee the SQL log for the last executed operation.")

    def _run(self, operation, **metadata):
        # New coordinator for the assignment's required pipeline.
        # Notebook SQL helpers built AND executed statements. This method asks
        # QueryBuilder for SQL, displays that exact string, then passes the same
        # string and parameters to CommandExecutor. It never assembles SQL itself.
        sql = self._builder.build(operation, **metadata)
        params = self._builder.get_parameters()
        if isinstance(params, list):
            description = f"Batch parameters: {len(params)} row(s); first 3: {params[:3]!r}"
        else:
            description = f"Parameters: {params!r}"
        self._write(self._sql_box, f"[{operation}]\n{sql}\n{description}\n\n", append=True)
        self._root.update_idletasks()  # paint the SQL before database execution
        try:
            result = self._executor.execute(operation, sql, params)
        except (sqlite3.Error, ValueError, TypeError, OverflowError):
            self._write(self._sql_box, "Executor: " + self._executor.get_status() + "\n\n", append=True)
            raise
        self._write(self._sql_box, "Executor: " + self._executor.get_status() + "\n\n", append=True)
        return result

    def load_paths(self, paths):
        # Adapted from Parsing.ipynb's DictReader example through TableData.
        # Loading only changes Python data. The Create/Insert buttons control SQL.
        errors = []
        for path in paths:
            try:
                table = TableData.from_csv(path)
                if table.get_name() in self._expected:
                    raise ValueError("Drop the existing table before reloading that CSV.")
                if any(n.lower() == table.get_name().lower() and n != table.get_name()
                       for n in self._tables):
                    raise ValueError("Another loaded table has the same name ignoring case.")
                table.get_row_key()
                self._tables[table.get_name()] = table
            except (OSError, ValueError, TypeError) as error:
                errors.append(f"{Path(path).name}: {error}")
        names = sorted(self._tables)
        self._table_menu.configure(values=names)
        if names:
            self._table_var.set(names[0])
            self._table_changed()
        summary = "CSV files loaded into Python only:\n" + "\n".join(str(self._tables[n]) for n in names)
        summary += "\n\nChoose Create Table, then Insert Data; or use Demo All Tables."
        summary += "\nDatabase is in memory by default; CSV files are never changed."
        if errors:
            summary += "\n\nLoad errors:\n" + "\n".join(errors)
        self._show(summary)

    def open_files(self):
        paths = filedialog.askopenfilenames(parent=self._root, filetypes=[("CSV files", "*.csv")])
        if paths:
            self.load_paths(paths)

    def _current(self):
        name = self._table_var.get()
        if name not in self._tables:
            raise ValueError("Load a CSV and select a table first.")
        return self._tables[name]

    def _table_changed(self, event=None):
        table = self._current()
        self._info_var.set(str(table) + " | " + str(self._executor.get_connection_settings()))
        self._column_menu.configure(values=table.get_columns())
        self._column_var.set(table.get_columns()[0])
        self._row_var.set("1")
        self._null_var.set(False)
        self._fill_value()

    def _fill_value(self, event=None):
        table = self._current()
        rows = table.get_rows()
        value = rows[0][self._column_var.get()] if rows else ""
        self._value_var.set("" if value is None else value.hex() if isinstance(value, bytes) else str(value))

    def create_table(self, display=True):
        table = self._current()
        name = table.get_name()
        existing = self._run("SELECT", table=name, schema=True)
        if existing and name not in self._expected:
            raise ValueError("That database table already exists. Drop it before importing this CSV.")
        self._run("CREATE", table=name, column_types=table.get_types())
        # New working model for validation, independent of SELECT results.
        # Source rows remain in TableData; this model tracks successful GUI edits.
        self._expected.setdefault(name, {})
        return self.check_table(display=display)

    def insert_data(self, display=True):
        table = self._current()
        name = table.get_name()
        if name not in self._expected:
            raise ValueError("Create Table before inserting its CSV rows.")
        if self._run("SELECT", table=name, count=True)[0][0] != 0:
            raise ValueError("Table is not empty. Drop and recreate it before importing again.")
        if len(table):
            self._run("INSERT", table=name, rows=table.get_rows())
            if self._executor.get_rowcount() != len(table):
                raise ValueError("INSERT affected an unexpected number of rows.")
        # Empty, ordinary rowid tables assign IDs starting at 1 in insert order.
        # These expected values come from Python source rows, NOT fetched SQL data.
        self._expected[name] = {i: row for i, row in enumerate(table, start=1)}
        return self.check_table(display=display)

    def select_all(self):
        table = self._current()
        rows = self._run("SELECT", table=table.get_name(),
                         columns=[table.get_row_key()] + table.get_columns(),
                         order_by=[table.get_row_key()])
        self._show(self._executor.get_status(), rows, ["Row ID"] + table.get_columns())
        return rows

    def _target(self):
        table = self._current()
        row_id = int(self._row_var.get())
        if row_id not in self._expected.get(table.get_name(), {}):
            raise ValueError("That Row ID is not in the current table. Use Select All to check IDs.")
        return table, row_id

    def update_row(self, display=True):
        # Adapted from DynamicSQL.ipynb's update_row() example: build a dict of
        # changed values. The selected column replaces a fixed planet attribute.
        table, row_id = self._target()
        column = self._column_var.get()
        if column not in table.get_columns():
            raise ValueError("Choose a valid update column.")
        value = None if self._null_var.get() else table.convert_input(column, self._value_var.get())
        self._run("UPDATE", table=table.get_name(), changes={column: value},
                  where={table.get_row_key(): row_id})
        if self._executor.get_rowcount() != 1:
            raise ValueError("UPDATE did not affect exactly one row.")
        self._expected[table.get_name()][row_id][column] = value
        return self.check_table(display=display)

    def delete_row(self, confirm=True, display=True):
        table, row_id = self._target()
        if confirm and not messagebox.askyesno("Delete Row", f"Delete Row ID {row_id} from {table.get_name()}?",
                                               parent=self._root):
            return
        self._run("DELETE", table=table.get_name(), where={table.get_row_key(): row_id})
        if self._executor.get_rowcount() != 1:
            raise ValueError("DELETE did not affect exactly one row.")
        del self._expected[table.get_name()][row_id]
        return self.check_table(display=display)

    def drop_table(self, confirm=True, display=True):
        table = self._current()
        name = table.get_name()
        if confirm and not messagebox.askyesno("Drop Table", f"Drop database table {name}? The CSV stays unchanged.",
                                               parent=self._root):
            return
        self._run("DROP", table=name)
        # New confirmation query; its SQL still goes through both dispatch tables.
        remaining = self._run("SELECT", table="sqlite_master", columns=["name"],
                              where={"type": "table", "name": name})
        if remaining:
            raise ValueError("DROP check failed: the table is still in SQLite.")
        self._expected.pop(name, None)
        if display:
            self._show(f"[PASS] DROP: {name} is absent from SQLite. The CSV is unchanged.")
        return True

    def check_table(self, display=True):
        # Added for this assignment's Validation Requirements; not copied from
        # a notebook. SQL.ipynb shows SELECT-after-change checks. Here compare
        # actual SQL results with a separately maintained Python working model.
        # Comparing only row counts would miss swapped columns or incorrect edits.
        table = self._current()
        name = table.get_name()
        if name not in self._expected:
            raise ValueError("Create Table before checking database contents.")
        schema = self._run("SELECT", table=name, schema=True)
        count = self._run("SELECT", table=name, count=True)[0][0]
        columns = table.get_columns()
        rows = self._run("SELECT", table=name, columns=[table.get_row_key()] + columns,
                         order_by=[table.get_row_key()])
        model = self._expected[name]
        expected = [(i,) + tuple(row[c] for c in columns) for i, row in sorted(model.items())]
        checks = [schema == list(table.get_types().items()), count == len(model), rows == expected]
        labels = ["Column names and inferred types match",
                  f"Row counts match: Python={len(model)}, SQLite={count}",
                  "SELECT contents match all Python working rows"]
        report = f"{name} | original CSV: {len(table)} row(s)\n"
        report += "\n".join(f"[{'PASS' if ok else 'FAIL'}] {label}" for ok, label in zip(checks, labels))
        report += "\nSchema: " + repr(schema)
        if display:
            self._show(report, rows, ["Row ID"] + columns)
        if not all(checks):
            raise ValueError(report)
        return {"table": name, "rows": count, "checks": checks}

    def demo_all(self, confirm=True):
        # New demonstration driver, not a pasted notebook script. It calls the
        # same methods as the six buttons, checks each stage, and restores the
        # source rows at the end. No dataset-specific SQL or field names are used.
        if not self._tables:
            raise ValueError("Load CSV files first.")
        if confirm and not messagebox.askyesno("Demo All Tables",
                "Recreate every loaded table and test create/insert/select/update/delete/drop?\n"
                "This replaces current database edits, then restores the original CSV rows.", parent=self._root):
            return
        summaries = []
        for name in sorted(self._tables):
            self._table_var.set(name)
            self._table_changed()
            table = self._current()
            self.drop_table(confirm=False, display=False)
            self.create_table(display=False)
            self.insert_data(display=False)
            count = self.check_table(display=False)["rows"]
            if count:
                column = table.get_columns()[0]
                kind = table.get_types()[column]
                value = table.get_rows()[0][column]
                new_value = {"INTEGER": "123", "REAL": "123.5", "TEXT": "Demo value", "BLOB": "abcd"}[kind]
                if str(value) == new_value:
                    new_value = {"INTEGER": "124", "REAL": "124.5", "TEXT": "Changed value", "BLOB": "abce"}[kind]
                self._value_var.set(new_value)
                self.update_row(display=False)
                self.delete_row(confirm=False, display=False)
                deleted_count = self.check_table(display=False)["rows"]
                if deleted_count != count - 1:
                    raise ValueError("Demo DELETE count did not decrease by one.")
            self.drop_table(confirm=False, display=False)
            self.create_table(display=False)
            self.insert_data(display=False)
            final_count = self.check_table(display=False)["rows"]
            details = "create, insert, select, update, delete, drop, restore" if count else "empty-table checks (update/delete skipped)"
            summaries.append(f"[PASS] {name}: {final_count} source rows restored; {details}.")
        self._table_var.set(sorted(self._tables)[0])
        self._table_changed()
        rows = self.select_all()
        table = self._current()
        self._show("\n".join(summaries) + "\n\nCurrent table: " + table.get_name(),
                   rows, ["Row ID"] + table.get_columns())
        return summaries

    # Accessors keep test/driver code from reaching into mutable table storage.
    def get_table_names(self):
        return sorted(self._tables)

    def get_sql_text(self):
        return self._sql_box.get("1.0", "end-1c")

    def get_results_text(self):
        return self._results_box.get("1.0", "end-1c")

    def get_last_error(self):
        return self._last_error

    def __str__(self):
        return f"SQLiteGUI: {len(self._tables)} loaded table(s)"

    def run(self):
        self._root.mainloop()

    def close(self):
        self._executor.close()
        self._root.destroy()


# Adapted from Tkinter.ipynb's MAIN block. Keep the import guard so importing
# classes in tests does not open a window. Move Tk(), layout and mainloop()
# into SQLiteGUI; outside the class the script only locates files and starts it.
if __name__ == "__main__":
    SQLiteGUI(Path(__file__).resolve().parent).run()
