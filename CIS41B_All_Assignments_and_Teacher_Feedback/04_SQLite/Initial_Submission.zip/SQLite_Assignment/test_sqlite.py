"""Additional checks written for this assignment, not claimed as notebook code.

Run from the extracted folder:
    python -m unittest -v test_sqlite
GUI tests need a display and are explicitly skipped when one is unavailable.
"""

import csv
import hashlib
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from table_data import TableData
from query_builder import QueryBuilder
from command_executor import CommandExecutor

ROOT = Path(__file__).resolve().parent
COUNTS = {"CO2": 731, "Dwarfs": 13, "Elements": 118, "Presidents": 44, "Temperature": 169}


class DataTests(unittest.TestCase):
    def test_all_five_real_files_and_exact_header_names(self):
        for name, expected_count in COUNTS.items():
            with self.subTest(table=name):
                data = TableData.from_csv(ROOT / (name + ".csv"))
                with open(ROOT / (name + ".csv"), newline="", encoding="utf-8-sig") as stream:
                    raw = list(csv.reader(stream))
                if name == "Temperature":
                    raw = raw[3:]
                self.assertEqual(data.get_columns(), raw[0])
                self.assertEqual(len(data), expected_count)
                self.assertEqual(len(data), len(raw) - 1)
                self.assertTrue(all(isinstance(row, dict) for row in data))

    def test_expected_types_for_all_real_files(self):
        types = {
            "CO2": ["INTEGER", "INTEGER", "REAL", "REAL", "REAL", "REAL", "INTEGER"],
            "Dwarfs": ["TEXT", "REAL", "REAL"],
            "Elements": ["INTEGER", "TEXT", "TEXT"],
            "Presidents": ["INTEGER"] + ["TEXT"] * 8,
            "Temperature": ["INTEGER", "REAL", "REAL", "REAL"],
        }
        for name, expected in types.items():
            with self.subTest(table=name):
                data = TableData.from_csv(ROOT / (name + ".csv"))
                self.assertEqual(list(data.get_types().values()), expected)

    def test_dwarf_names_remain_text_and_periods_are_real(self):
        data = TableData.from_csv(ROOT / "Dwarfs.csv")
        self.assertEqual(data.get_types(), {"Dwarf": "TEXT", "Distance(AU)": "REAL", "Period(years)": "REAL"})
        self.assertTrue(all(isinstance(r["Dwarf"], str) for r in data))
        self.assertEqual(data.get_rows()[0]["Period(years)"], 980.0)
        self.assertTrue(any(r["Dwarf"] == "90568" for r in data))

    def test_source_values_are_not_silently_corrected(self):
        elements = TableData.from_csv(ROOT / "Elements.csv")
        self.assertEqual(next(r for r in elements if r["Element"] == "Aluminium")["Abbreviation"], "A")
        presidents = TableData.from_csv(ROOT / "Presidents.csv")
        self.assertEqual(presidents.get_rows()[-1]["Left office "], "Incumbent ")
        self.assertEqual(presidents.get_rows()[-1]["Party "], "  Democratic   ")

    def test_empty_null_and_later_decimal(self):
        data = TableData("Mixed", [{"x": "", "code": "001"}, {"x": "2", "code": "002"},
                                   {"x": "2.5", "code": "003"}])
        self.assertEqual(data.get_types(), {"x": "REAL", "code": "TEXT"})
        self.assertEqual(data.get_rows()[0], {"x": None, "code": "001"})
        self.assertEqual(data.get_rows()[-1]["x"], 2.5)

    def test_typed_dicts_blob_null_and_real(self):
        data = TableData("Typed", [{"i": 1, "r": 1.5, "b": b"\x00\xff", "n": None}])
        self.assertEqual(data.get_types(), {"i": "INTEGER", "r": "REAL", "b": "BLOB", "n": "TEXT"})
        self.assertEqual(data.convert_input("b", "ff01"), b"\xff\x01")

    def test_encapsulation_iteration_and_equality(self):
        data = TableData("Sample", [{"a": 1}])
        self.assertEqual(data, TableData("Sample", [{"a": 1}]))
        self.assertNotEqual(data, TableData("Sample", [{"a": 2}]))
        self.assertIs(data.__eq__(123), NotImplemented)
        data.get_rows()[0]["a"] = 9
        next(iter(data))["a"] = 9
        data.get_types()["a"] = "TEXT"
        self.assertEqual(data.get_rows(), [{"a": 1}])
        self.assertEqual(data.get_types(), {"a": "INTEGER"})
        self.assertIn("1 rows", str(data))

    def test_bad_input_and_duplicate_headers(self):
        for rows, columns in [([{"x": 1}], ["x", "X"]), ([{"x": 1}, {"y": 2}], None),
                              ([{"x": []}], None)]:
            with self.subTest(rows=rows), self.assertRaises((TypeError, ValueError)):
                TableData("Bad", rows, columns)
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "bad.csv"
            filename.write_text("a,b\n1,2,3\n")
            with self.assertRaises(ValueError):
                TableData.from_csv(filename)

    def test_quoted_newline_in_csv_and_preamble(self):
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "notes.csv"
            filename.write_text('# note\na,b\n1,"line one\n#line two"\n', encoding="utf-8")
            data = TableData.from_csv(filename)
            self.assertEqual(data.get_rows(), [{"a": 1, "b": "line one\n#line two"}])

    def test_single_column_days_header_is_not_a_comment(self):
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "Days.csv"
            filename.write_text("#days\n10\n20\n")
            data = TableData.from_csv(filename)
            self.assertEqual(data.get_columns(), ["#days"])
            self.assertEqual(data.get_rows(), [{"#days": 10}, {"#days": 20}])

    def test_header_only_table(self):
        data = TableData("Empty", [], ["a", "b"])
        self.assertEqual(len(data), 0)
        self.assertEqual(data.get_types(), {"a": "TEXT", "b": "TEXT"})

    def test_rowid_name_collision(self):
        data = TableData("Collision", [{"rowid": 12, "x": "test"}])
        self.assertEqual(data.get_row_key(), "_rowid_")

    def test_input_conversion_rejects_lossy_or_invalid_values(self):
        data = TableData("Numbers", [{"i": 1, "r": 1.5}])
        for column, text in [("i", "1.5"), ("i", str(2 ** 70)), ("r", "nan"), ("r", "inf")]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                data.convert_input(column, text)
        self.assertEqual(TableData("Large", [{"x": str(2 ** 70)}]).get_types()["x"], "TEXT")


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.builder = QueryBuilder()
        self.executor = CommandExecutor()

    def tearDown(self):
        self.executor.close()

    def run_query(self, operation, **metadata):
        sql = self.builder.build(operation, **metadata)
        self.assertIsInstance(sql, str)
        return self.executor.execute(operation, sql, self.builder.get_parameters())

    def make_table(self, data):
        self.run_query("CREATE", table=data.get_name(), column_types=data.get_types())
        if len(data):
            self.run_query("INSERT", table=data.get_name(), rows=data.get_rows())

    def test_complete_crud_and_drop_for_every_real_file(self):
        for name in COUNTS:
            with self.subTest(table=name):
                data = TableData.from_csv(ROOT / (name + ".csv"))
                self.make_table(data)
                columns = data.get_columns()
                key = data.get_row_key()
                source = [tuple(r[c] for c in columns) for r in data]
                self.assertEqual(self.run_query("SELECT", table=name, count=True)[0][0], COUNTS[name])
                self.assertEqual(self.run_query("SELECT", table=name, schema=True), list(data.get_types().items()))
                self.assertEqual(self.run_query("SELECT", table=name, order_by=[key]), source)
                self.assertEqual(self.run_query("SELECT", table=name, where={key: 1}), [source[0]])
                change = 999 if data.get_types()[columns[0]] == "INTEGER" else "Test change"
                self.run_query("UPDATE", table=name, changes={columns[0]: change}, where={key: 1})
                self.assertEqual(self.executor.get_rowcount(), 1)
                expected = [(change,) + source[0][1:]] + source[1:]
                self.assertEqual(self.run_query("SELECT", table=name, order_by=[key]), expected)
                self.run_query("DELETE", table=name, where={key: 1})
                self.assertEqual(self.executor.get_rowcount(), 1)
                self.assertEqual(self.run_query("SELECT", table=name, order_by=[key]), source[1:])
                self.run_query("DROP", table=name)
                self.assertEqual(self.run_query("SELECT", table=name, schema=True), [])

    def test_both_dispatch_dictionaries(self):
        operations = {"CREATE", "INSERT", "SELECT", "UPDATE", "DELETE", "DROP"}
        self.assertEqual(set(self.builder.dispatch), operations)
        self.assertEqual(set(self.executor.exec_dispatch), operations)
        self.assertEqual(self.executor.exec_dispatch["INSERT"], self.executor.exec_dispatch["DELETE"])

    def test_sql_string_is_built_without_database_side_effects(self):
        sql = self.builder.build("CREATE", table="NotYet", column_types={"a": "INTEGER"})
        self.assertEqual(self.builder.get_last_sql(), sql)
        self.assertEqual(self.run_query("SELECT", table="NotYet", schema=True), [])

    def test_reordered_dictionary_keys_keep_values_aligned(self):
        self.run_query("CREATE", table="OrderTest", column_types={"a": "INTEGER", "b": "TEXT"})
        self.run_query("INSERT", table="OrderTest", rows=[{"a": 1, "b": "x"}, {"b": "y", "a": 2}])
        self.assertEqual(self.run_query("SELECT", table="OrderTest", order_by=["rowid"]), [(1, "x"), (2, "y")])

    def test_quotes_special_names_and_sql_looking_values(self):
        name = 'odd " name; --'
        value = "O'Brien'); DROP TABLE anything; --"
        data = TableData(name, [{'a " field': value, "#days": 2, "Period(years)": 1.5}])
        self.make_table(data)
        self.assertEqual(self.run_query("SELECT", table=name), [(value, 2, 1.5)])
        self.run_query("UPDATE", table=name, changes={'a " field': "D'Angelo"}, where={"#days": 2})
        self.assertEqual(self.run_query("SELECT", table=name)[0][0], "D'Angelo")

    def test_null_where_clause_and_multi_field_update(self):
        data = TableData("Nulls", [{"a": "", "b": 1}, {"a": "x", "b": 2}])
        self.make_table(data)
        self.assertEqual(self.run_query("SELECT", table="Nulls", where={"a": None}), [(None, 1)])
        self.run_query("UPDATE", table="Nulls", changes={"a": "changed", "b": 3}, where={"a": None})
        self.assertEqual(self.run_query("SELECT", table="Nulls", where={"b": 3}), [("changed", 3)])

    def test_insert_batch_failure_reverts_earlier_rows(self):
        self.run_query("CREATE", table="Atomic", column_types={"a": "INTEGER", "b": "TEXT"})
        sql = self.builder.build("INSERT", table="Atomic", rows=[{"a": 1, "b": "first"}, {"a": 2, "b": "second"}])
        params = self.builder.get_parameters()
        params[1] = (2,)  # Deliberately break the second row, after the first executes.
        with self.assertRaises(sqlite3.ProgrammingError):
            self.executor.execute("INSERT", sql, params)
        self.assertIn("rolled back", self.executor.get_status())
        self.assertEqual(self.executor.get_last_results(), [])
        self.assertEqual(self.run_query("SELECT", table="Atomic"), [])

    def test_failed_update_and_delete_leave_existing_data(self):
        self.make_table(TableData("Original", [{"a": 1}]))
        for operation, kwargs in [("UPDATE", {"table": "Original", "changes": {"not_a_column": 3}, "where": {"rowid": 1}}),
                                  ("DELETE", {"table": "NoSuchTable", "where": {"rowid": 1}})]:
            with self.subTest(operation=operation):
                with self.assertRaises(sqlite3.OperationalError):
                    self.run_query(operation, **kwargs)
                self.assertIn("rolled back", self.executor.get_status())
                self.assertEqual(self.run_query("SELECT", table="Original"), [(1,)])

    def test_rollback_is_called_for_each_modifying_operation(self):
        class TrackedConnection(sqlite3.Connection):
            rollback_count = 0

            def rollback(self):
                self.rollback_count += 1
                super().rollback()

        connection = sqlite3.connect(":memory:", factory=TrackedConnection)
        with patch("command_executor.sqlite3.connect", return_value=connection):
            executor = CommandExecutor()
        cases = [("INSERT", {"table": "missing", "rows": [{"a": 1}]}),
                 ("UPDATE", {"table": "missing", "changes": {"a": 2}, "where": {"a": 1}}),
                 ("DELETE", {"table": "missing", "where": {"a": 1}})]
        try:
            for expected_calls, (operation, metadata) in enumerate(cases, 1):
                sql = self.builder.build(operation, **metadata)
                with self.assertRaises(sqlite3.Error):
                    executor.execute(operation, sql, self.builder.get_parameters())
                self.assertEqual(connection.rollback_count, expected_calls)
        finally:
            executor.close()

    def test_missing_conditions_and_unsupported_operations(self):
        with self.assertRaises(ValueError):
            self.builder.build("UPDATE", table="x", changes={"a": 2}, where={})
        with self.assertRaises(ValueError):
            self.builder.build("DELETE", table="x", where={})
        with self.assertRaises(ValueError):
            self.builder.build("VACUUM", table="x")
        with self.assertRaises(ValueError):
            self.builder.build("CREATE", table="x", column_types={"a": "TEXT; DROP TABLE x"})

    def test_last_results_accessors_and_iteration(self):
        self.make_table(TableData("Rows", [{"a": 1}]))
        result = self.run_query("SELECT", table="Rows")
        result.append((99,))
        self.assertEqual(list(self.executor), [(1,)])
        self.assertEqual(self.executor.get_columns(), ["a"])
        settings = self.executor.get_connection_settings()
        settings["database"] = "changed"
        self.assertEqual(self.executor.get_connection_settings()["database"], ":memory:")
        self.assertIn("CommandExecutor", str(self.executor))
        self.assertIn("SELECT", str(self.builder))

    def test_failed_select_clears_stale_results(self):
        self.make_table(TableData("Rows", [{"a": 1}]))
        self.run_query("SELECT", table="Rows")
        with self.assertRaises(sqlite3.Error):
            self.run_query("SELECT", table="missing")
        self.assertEqual(self.executor.get_last_results(), [])

    def test_file_database_persists_and_close_is_safe(self):
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "check.db"
            executor = CommandExecutor(filename)
            sql = self.builder.build("CREATE", table="Persist", column_types={"a": "INTEGER"})
            executor.execute("CREATE", sql)
            sql = self.builder.build("INSERT", table="Persist", rows=[{"a": 8}])
            executor.execute("INSERT", sql, self.builder.get_parameters())
            executor.close()
            executor.close()
            executor = CommandExecutor(filename)
            sql = self.builder.build("SELECT", table="Persist")
            self.assertEqual(executor.execute("SELECT", sql), [(8,)])
            executor.close()
            with self.assertRaises(ValueError):
                executor.execute("SELECT", sql)

    def test_hidden_id_collision_round_trip(self):
        data = TableData("Collision", [{"rowid": 9, "x": "first"}, {"rowid": 9, "x": "second"}])
        self.make_table(data)
        self.run_query("UPDATE", table="Collision", changes={"x": "changed"}, where={data.get_row_key(): 2})
        self.assertEqual(self.run_query("SELECT", table="Collision", order_by=[data.get_row_key()]),
                         [(9, "first"), (9, "changed")])


class GUITests(unittest.TestCase):
    def setUp(self):
        import tkinter as tk
        from sqlite_gui import SQLiteGUI
        try:
            self.gui = SQLiteGUI(ROOT)
        except tk.TclError as error:
            self.skipTest(f"No graphical display: {error}")
        self.confirm = patch("sqlite_gui.messagebox.askyesno", return_value=True)
        self.confirm.start()

    def tearDown(self):
        self.confirm.stop()
        self.gui.close()

    def click(self, label):
        # Widget access is test-only: invoke the real registered Tk callback.
        self.gui._buttons[label].invoke()
        self.gui._root.update_idletasks()
        self.assertIsNone(self.gui.get_last_error(), self.gui.get_results_text())

    def choose(self, table):
        self.gui._table_var.set(table)
        self.gui._table_changed()

    def test_six_real_buttons_for_each_csv(self):
        self.assertEqual(set(self.gui.get_table_names()), set(COUNTS))
        for name, count in COUNTS.items():
            with self.subTest(table=name):
                self.choose(name)
                self.click("Create Table")
                self.click("Insert Data")
                self.assertIn(f"Python={count}, SQLite={count}", self.gui.get_results_text())
                self.click("Select All")
                self.assertIn(f"SELECT returned {count} row(s).", self.gui.get_results_text())
                self.gui._value_var.set("999" if name != "Dwarfs" else "Changed dwarf")
                self.click("Update Row")
                self.assertIn("[PASS] SELECT contents", self.gui.get_results_text())
                self.click("Delete Row")
                self.assertIn(f"Python={count - 1}, SQLite={count - 1}", self.gui.get_results_text())
                self.click("Drop Table")
                self.assertIn("[PASS] DROP", self.gui.get_results_text())

    def test_demo_all_button_finishes_with_original_rows(self):
        before = {name: hashlib.sha256((ROOT / (name + ".csv")).read_bytes()).hexdigest() for name in COUNTS}
        self.click("Demo All Tables")
        for name, count in COUNTS.items():
            self.assertIn(f"[PASS] {name}: {count} source rows restored", self.gui.get_results_text())
        for name, count in COUNTS.items():
            self.choose(name)
            self.assertEqual(self.gui.check_table(display=False)["rows"], count)
            self.assertEqual(hashlib.sha256((ROOT / (name + ".csv")).read_bytes()).hexdigest(), before[name])

    def test_sql_is_visible_exactly_before_executor_receives_it(self):
        original = self.gui._executor.execute
        observed = []

        def observing_execute(operation, sql, params=()):
            self.assertIn(sql, self.gui.get_sql_text())
            observed.append(operation)
            return original(operation, sql, params)

        with patch.object(self.gui._executor, "execute", side_effect=observing_execute):
            self.click("Create Table")
            self.click("Insert Data")
        self.assertIn("CREATE", observed)
        self.assertIn("INSERT", observed)
        self.assertIn("VALUES (?,", self.gui.get_sql_text())

    def test_bad_order_repeat_insert_and_invalid_edit_report_errors(self):
        self.gui._buttons["Insert Data"].invoke()
        self.assertIsNotNone(self.gui.get_last_error())
        self.click("Create Table")
        self.click("Insert Data")
        self.gui._buttons["Insert Data"].invoke()
        self.assertIn("not empty", self.gui.get_last_error())
        self.gui._value_var.set("not an integer")
        self.gui._buttons["Update Row"].invoke()
        self.assertIsNotNone(self.gui.get_last_error())
        self.assertEqual(self.gui.check_table(display=False)["rows"], 731)

    def test_validation_detects_actual_wrong_data(self):
        self.click("Create Table")
        self.click("Insert Data")
        # Make an intentional out-of-band change without updating the Python
        # model. Check Table must not certify its own fetched rows as correct.
        sql = self.gui._builder.build("UPDATE", table="CO2", changes={"year": -10}, where={"rowid": 1})
        self.gui._executor.execute("UPDATE", sql, self.gui._builder.get_parameters())
        with self.assertRaises(ValueError):
            self.gui.check_table(display=False)

    def test_cancel_delete_and_drop_preserve_data(self):
        self.click("Create Table")
        self.click("Insert Data")
        with patch("sqlite_gui.messagebox.askyesno", return_value=False):
            self.click("Delete Row")
            self.click("Drop Table")
        self.assertEqual(self.gui.check_table(display=False)["rows"], 731)

    def test_new_csv_with_unknown_columns_uses_same_gui(self):
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "Extra.csv"
            filename.write_text('new column,another(value)\n"O\'Brien",1.25\nSecond,2.50\n')
            with patch("sqlite_gui.filedialog.askopenfilenames", return_value=[str(filename)]):
                self.click("Load CSV")
            self.choose("Extra")
            self.click("Create Table")
            self.click("Insert Data")
            self.assertEqual(self.gui.check_table(display=False)["rows"], 2)
            self.gui._column_var.set("another(value)")
            self.gui._value_var.set("3.75")
            self.click("Update Row")
            self.click("Delete Row")
            self.click("Drop Table")

    def test_empty_table_demo_and_null_update(self):
        self.click("Create Table")
        self.click("Insert Data")
        self.gui._null_var.set(True)
        self.click("Update Row")
        self.assertIn("NULL", self.gui.get_results_text())
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "Empty.csv"
            filename.write_text("a,b\n")
            self.gui.load_paths([filename])
            self.choose("Empty")
            self.click("Create Table")
            self.click("Insert Data")
            self.assertEqual(self.gui.check_table(display=False)["rows"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
