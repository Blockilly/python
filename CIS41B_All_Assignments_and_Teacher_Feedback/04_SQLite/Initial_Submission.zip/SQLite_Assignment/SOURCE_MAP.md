# Notebook adaptation map

| Part of this solution | Classroom source | Kept / changed |
|---|---|---|
| Class structure | `ClassDesign.ipynb`, **Complete**, `CaesarCipher` (cell 14); `ExampleAssignment.ipynb`, **Step 8** (cells 14-15) | Keep state, accessors, helper methods and public behavior. Replace cipher behavior with table loading, SQL generation, execution and GUI coordination. |
| CSV loading | `Parsing.ipynb`, **1 — CSV Reading & Writing**, **1b: csv.DictReader — access fields by name** (cell 7) | Keep `DictReader` and the file context manager; return all row dictionaries instead of printing fixed student fields. |
| Type inference | `DynamicSQL.ipynb`, **Inferring SQLite Types from Python Values**, `sqlite_type()` (cell 5) | Keep INTEGER/REAL/TEXT/BLOB mapping. Inspect whole CSV columns before converting because CSV values begin as strings. |
| CREATE | `DynamicSQL.ipynb`, **Building a CREATE TABLE Statement Dynamically**, `create_table()` (cell 7) | Keep joined column definitions. Dictionary keys replace namedtuple fields; the method returns SQL instead of executing it. |
| INSERT | `DynamicSQL.ipynb`, **Building an INSERT Statement Dynamically**, `insert_row()` (cell 9); `SqliteDB.py`, `insert_namedtuple_batch()` | Keep field order and one `?` per column. Dictionary values become ordered parameter tuples; the executor performs the batch. |
| UPDATE / DELETE | `DynamicSQL.ipynb`, the corresponding **Building ... Dynamically** sections, `update_row()` / `delete_row()` (cells 11 / 13) | Keep generated SET fragments and parameterized WHERE. Replace the fixed `name` lookup with dictionary conditions. |
| SELECT / DROP | `DynamicSQL.ipynb`, **Building a SELECT Statement Dynamically**, `select_all()` (cell 15); `SqliteDB.py`, `delete_table()` | Keep generated table names, fetchall and DROP IF EXISTS. Move execution into its own class. |
| Connection / rollback | `SQL.ipynb`, **Using SQLite from Python** (cells 3-4), **Transactions** (cells 28-29); `SqliteDB.py`, modification helpers | Keep connect/execute/commit/rollback. Store the connection in CommandExecutor and report errors to the GUI. |
| Accessors and dunders | `Dunders.ipynb`, **Student Class** and **GradingSystem Class** (cells 4-7); `ClassDesign.ipynb`, **Complete** | Keep copied accessors, iteration and readable summaries. TableData equality compares snapshots rather than student names or cipher settings. |
| GUI layout / events | `Tkinter.ipynb`, `TkinterShowcase.__init__`, `build_textbox_tab()`, `build_button_tab()`, `build_menu_tab()` (code in cell 2, explanations in cells 4/8/14) | Keep frames, ScrolledText and callbacks. Replace showcase tabs with two displays, table/column selectors and operation buttons. |

Cell numbers above count all cells from 1, not execution counts. Section and method names are the primary references.

## What is new rather than copied

The two dispatch-based class wrappers follow the SQLite assignment's explicit design.
CSV preamble handling, whole-column inference, identifier quoting, generic WHERE dictionaries,
hidden-row-ID selection, schema/count/full-content validation, typed GUI editing, and the all-table
demo are new adaptations for these requirements. They are labeled that way in the code.
The test suite is new verification code, not attributed to a classroom notebook.

The notebook contains complete class definitions and explains the changes before each class.
The Python modules contain the same class code, with comments next to the adapted methods.
